export function GoldBar({
  kicker = "A shedding table",
  subtitle = "Empty your hand first. Last card can still tax you.",
}: {
  kicker?: string;
  subtitle?: string;
}) {
  return (
    <div className="gold-bar mx-auto w-full max-w-[34rem]">
      <div className="gold-bar-inner">
        <p className="gold-bar-kicker">{kicker}</p>
        <h1>SWIFT HAND</h1>
        <p className="gold-bar-sub">{subtitle}</p>
      </div>
    </div>
  );
}
