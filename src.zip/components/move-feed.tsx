import { useEffect, useRef, useState } from "react";
import { feedCardLabel, isJoker, isRedSuit, suitOf } from "@/game/cards.ts";
import type { Card, TableLog } from "@/game/types.ts";
import { cn } from "@/lib/utils";

const LIVE_MS = 5000;
const FADE_MS = 800;

function CardBits({ cards }: { cards: Card[] }) {
  return (
    <>
      {cards.map((card, i) => (
        <span key={`${card.id}-${i}`}>
          {i > 0 && <span className="mx-1 text-muted-foreground/80">→</span>}
          <span
            className={cn(
              "font-semibold tracking-wide",
              isJoker(card)
                ? card.jokerColor === "red"
                  ? "text-crimson"
                  : "text-ivory"
                : isRedSuit(suitOf(card))
                  ? "text-crimson"
                  : "text-ivory",
            )}
          >
            {feedCardLabel(card)}
          </span>
        </span>
      ))}
    </>
  );
}

export function MoveFeed({ log }: { log: TableLog[] }) {
  const born = useRef(new Map<string, number>());
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 200);
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => {
    const stamp = Date.now();
    for (const line of log) {
      if ((line.kind === "dump" || line.kind === "pickup") && !born.current.has(line.id)) {
        born.current.set(line.id, stamp);
      }
    }
  }, [log]);

  const lines = log.filter((l) => {
    if (l.kind !== "dump" && l.kind !== "pickup") return false;
    const at = born.current.get(l.id);
    if (at == null) return true;
    return now - at < LIVE_MS;
  });
  if (!lines.length) return null;

  return (
    <ol className="kill-feed pointer-events-none absolute top-28 left-3 z-20 flex max-w-[min(20rem,calc(100%-6.5rem))] flex-col gap-1 sm:left-5">
      {lines.map((line) => {
        const age = now - (born.current.get(line.id) ?? now);
        const fade = age > LIVE_MS - FADE_MS ? Math.max(0, (LIVE_MS - age) / FADE_MS) : 1;
        return (
          <li key={line.id} className="kill-feed-line" style={{ opacity: fade }}>
            {line.kind === "dump" && line.cards?.length ? (
              <p>
                <span className="font-semibold text-brass">{line.playerName}</span>
                <span className="text-ivory/80"> played </span>
                <CardBits cards={line.cards} />
              </p>
            ) : (
              <p>
                <span className="font-semibold text-brass">{line.playerName}</span>
                <span className="text-ivory/80">
                  {" "}
                  picked up {line.count ?? 1} {(line.count ?? 1) === 1 ? "card" : "cards"}.
                </span>
              </p>
            )}
          </li>
        );
      })}
    </ol>
  );
}
