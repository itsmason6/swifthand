import { feedCardLabel, isJoker, isRedSuit, suitOf } from "@/game/cards.ts";
import type { Card, TableLog } from "@/game/types.ts";
import { cn } from "@/lib/utils";

function CardBits({ cards }: { cards: Card[] }) {
  return (
    <>
      {cards.map((card, i) => (
        <span key={`${card.id}-${i}`}>
          {i > 0 && <span className="mx-1 text-muted-foreground/80">→</span>}
          <span
            className={cn(
              "font-semibold tracking-wide",
              isJoker(card)
                ? card.jokerColor === "red"
                  ? "text-crimson"
                  : "text-ivory"
                : isRedSuit(suitOf(card))
                  ? "text-crimson"
                  : "text-ivory",
            )}
          >
            {feedCardLabel(card)}
          </span>
        </span>
      ))}
    </>
  );
}

export function MoveFeed({ log }: { log: TableLog[] }) {
  const lines = log.filter((l) => l.kind === "dump" || l.kind === "pickup").slice(-8);
  if (!lines.length) return null;

  return (
    <ol className="kill-feed pointer-events-none absolute top-16 left-3 z-30 flex max-w-[min(36rem,calc(100%-6rem))] flex-col gap-1 sm:left-5">
      {lines.map((line, i) => {
        const age = lines.length - 1 - i;
        return (
          <li
            key={line.id}
            className="kill-feed-line"
            style={{ opacity: Math.max(0.45, 1 - age * 0.08) }}
          >
            {line.kind === "dump" && line.cards?.length ? (
              <p>
                <span className="font-semibold text-brass">{line.playerName}</span>
                <span className="text-ivory/80"> played </span>
                <CardBits cards={line.cards} />
              </p>
            ) : (
              <p>
                <span className="font-semibold text-brass">{line.playerName}</span>
                <span className="text-ivory/80">
                  {" "}
                  picked up {line.count ?? 1} {(line.count ?? 1) === 1 ? "card" : "cards"}.
                </span>
              </p>
            )}
          </li>
        );
      })}
    </ol>
  );
}
