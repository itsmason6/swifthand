import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { ArrowLeftRight, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { PlayingCard, CardFan } from "@/components/playing-card";
import { SuitPip } from "@/components/suit-pip";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GoldBar } from "@/components/gold-bar";
import { HowToPlay } from "@/components/how-to-play";
import { MoveFeed } from "@/components/move-feed";
import {
  SequentialFlights,
  dumpSteps,
  fallbackBox,
  measure,
  pickupSteps,
  type Box,
  type PlayStep,
} from "@/components/card-flight";
import { canFollow, canPlayFirst, currentPlayer, playSuit, stillInPlayers, topCard } from "@/game/rules.ts";
import { isJoker, suitName } from "@/game/cards.ts";
import type { Card, GameAction, GameState, Suit } from "@/game/types.ts";
import { cn } from "@/lib/utils";
import { isMuted, setMuted, sfxPlay, unlockAudio } from "@/audio/sfx.ts";

const SUITS: Suit[] = ["spades", "hearts", "diamonds", "clubs"];
const SUIT_ORDER: Record<Suit, number> = { spades: 0, hearts: 1, diamonds: 2, clubs: 3 };
type HandSort = "suit" | "rank";

function rankValue(card: Card): number {
  if (card.rank === "joker") return 15;
  return card.rank;
}

function sortHand(hand: Card[], mode: HandSort): Card[] {
  const copy = hand.slice();
  if (mode === "suit") {
    copy.sort((a, b) => {
      if (isJoker(a) || isJoker(b)) {
        if (isJoker(a) && isJoker(b)) return (a.jokerColor === "red" ? 1 : 0) - (b.jokerColor === "red" ? 1 : 0);
        return isJoker(a) ? 1 : -1;
      }
      const s = SUIT_ORDER[a.suit] - SUIT_ORDER[b.suit];
      if (s) return s;
      return rankValue(a) - rankValue(b);
    });
  } else {
    copy.sort((a, b) => {
      const r = rankValue(a) - rankValue(b);
      if (r) return r;
      return SUIT_ORDER[a.suit] - SUIT_ORDER[b.suit];
    });
  }
  return copy;
}

function opponentOrder(state: GameState, selfSeat: number) {
  const others = stillInPlayers(state).filter((p) => p.seat !== selfSeat);
  const folded = state.players.filter((p) => p.seat !== selfSeat && (p.folded || p.goneOut));
  return [...others, ...folded];
}

export function GameTable({
  state,
  selfId,
  onAction,
  onLeave,
  online,
}: {
  state: GameState;
  selfId: string;
  onAction: (action: GameAction) => void;
  onLeave?: () => void;
  online?: boolean;
}) {
  const self = state.players.find((p) => p.id === selfId) ?? state.players[0]!;
  const actor = currentPlayer(state);
  const mine = actor?.id === self.id;
  const top = topCard(state);
  const [selection, setSelection] = useState<Card[]>([]);
  const [mute, setMute] = useState(isMuted());
  const [chat, setChat] = useState("");
  const [playQueue, setPlayQueue] = useState<PlayStep[]>([]);
  const [heldTop, setHeldTop] = useState<Card | null>(null);
  const [hiddenIds, setHiddenIds] = useState<Set<string>>(new Set());
  const [bounceSeat, setBounceSeat] = useState<string | null>(null);
  const [pilePulse, setPilePulse] = useState(0);
  const cardRects = useRef(new Map<string, Box>());
  const prevLogIds = useRef<string[] | null>(null);
  const prevHandIds = useRef(new Set<string>());
  const [handSort, setHandSort] = useState<HandSort>(() => {
    try {
      return localStorage.getItem("swift-hand-sort") === "rank" ? "rank" : "suit";
    } catch {
      return "suit";
    }
  });

  const opponents = opponentOrder(state, self.seat);

  useEffect(() => {
    const ids = new Set(self.hand.map((c) => c.id));
    setSelection((s) => {
      const next = s.filter((c) => ids.has(c.id));
      return next.length === s.length ? s : next;
    });
  }, [self.hand]);

  const ctx = { stillIn: stillInPlayers(state).filter((p) => !p.goneOut).length };
  const shownHand = sortHand(self.hand, handSort);

  function setSort(mode: HandSort) {
    setHandSort(mode);
    try {
      localStorage.setItem("swift-hand-sort", mode);
    } catch {
      /* ignore */
    }
  }

  useLayoutEffect(() => {
    const recordRects = () => {
      const next = new Map<string, Box>();
      document.querySelectorAll<HTMLElement>("[data-card-id]").forEach((el) => {
        const id = el.dataset.cardId;
        const box = measure(el);
        if (id && box) next.set(id, box);
      });
      cardRects.current = next;
    };

    if (prevLogIds.current === null) {
      prevLogIds.current = state.log.map((l) => l.id);
      prevHandIds.current = new Set(self.hand.map((c) => c.id));
      recordRects();
      return;
    }

    const seen = new Set(prevLogIds.current);
    const fresh = state.log.filter((l) => (l.kind === "dump" || l.kind === "pickup") && !seen.has(l.id));
    prevLogIds.current = state.log.map((l) => l.id);

    const draw = measure(document.querySelector("[data-draw-pile]"));
    const table = measure(document.querySelector("[data-discard-pile]"));
    const selfHand = measure(document.querySelector("[data-self-hand]"));
    const spawned: PlayStep[] = [];
    const hide: string[] = [];
    const gained = self.hand.filter((c) => !prevHandIds.current.has(c.id));
    prevHandIds.current = new Set(self.hand.map((c) => c.id));

    for (const line of fresh) {
      const who = line.playerId ?? state.players.find((p) => p.name === line.playerName)?.id;
      const minePlay = who === selfId;
      const seatBox = measure(document.querySelector(`[data-seat="${who ?? ""}"]`));

      if (line.kind === "dump" && line.cards?.length && table) {
        const prior = state.discard[state.discard.length - 1 - line.cards.length] ?? null;
        setHeldTop(prior);
        spawned.push(
          ...dumpSteps(
            line.cards,
            (card) => {
              if (minePlay) return cardRects.current.get(card.id) ?? fallbackBox(selfHand);
              return fallbackBox(seatBox ?? selfHand);
            },
            table,
          ),
        );
      }

      if (line.kind === "pickup" && draw) {
        const dest = minePlay ? fallbackBox(selfHand, 80, 116) : fallbackBox(seatBox, 42, 61);
        const faceCards = minePlay ? gained : undefined;
        if (minePlay) hide.push(...gained.map((c) => c.id));
        spawned.push(...pickupSteps(line.count ?? Math.max(gained.length, 1), faceCards, draw, dest, minePlay));
      }
    }

    if (spawned.length) {
      setPlayQueue((q) => [...q, ...spawned]);
      const who = fresh.find((l) => l.playerId)?.playerId;
      if (who) {
        setBounceSeat(who);
        window.setTimeout(() => setBounceSeat((s) => (s === who ? null : s)), 340);
      }
    } else if (state.phase === "animating") {
      onAction({ type: "resolve-play" });
    }
    if (hide.length) setHiddenIds((s) => new Set([...s, ...hide]));
    recordRects();
  }, [state.log, self.hand, selfId, state.players]);

  function finishStep(step: PlayStep) {
    if (step.landCard) {
      setHeldTop(step.landCard);
      setPilePulse((n) => n + 1);
    }
    setPlayQueue((q) => {
      const next = q.slice(1);
      if (next.length === 0) {
        setHiddenIds(new Set());
        queueMicrotask(() => onAction({ type: "resolve-play" }));
      }
      return next;
    });
  }

  useEffect(() => {
    const step = playQueue[0];
    if (!step) return;
    if (step.landCard) sfxPlay.place();
    else sfxPlay.pickup();
  }, [playQueue[0]?.id]);

  const displayTop = playQueue.length > 0 ? heldTop : top;

  function legalToAdd(card: Card): boolean {
    if (!mine || state.phase === "hand-over" || state.phase === "lobby" || state.phase === "animating") return false;
    if (state.phase === "pick-suit") return false;
    if (selection.length === 0) return canPlayFirst(card, state);
    return canFollow(selection[selection.length - 1]!, card, ctx);
  }

  function toggleCard(card: Card) {
    unlockAudio();
    if (selection.length && selection[selection.length - 1]!.id === card.id) {
      setSelection((s) => s.slice(0, -1));
      return;
    }
    if (selection.some((c) => c.id === card.id)) return;
    if (!legalToAdd(card)) {
      sfxPlay.error();
      return;
    }
    sfxPlay.place();
    setSelection((s) => [...s, card]);
  }

  function dump(forceHang = false) {
    if (!selection.length) return;
    onAction({ type: "dump", cardIds: selection.map((c) => c.id), forceHang });
  }

  function pickup() {
    onAction({ type: "pickup" });
    setSelection([]);
  }

  const waitingOnMe =
    mine &&
    playQueue.length === 0 &&
    state.phase !== "animating" &&
    (state.phase === "turn" ||
      state.phase === "queen-prompt" ||
      state.phase === "bounce-prompt" ||
      state.phase === "pick-suit");

  return (
    <div className="felt-table relative flex min-h-dvh flex-col overflow-hidden">
      <MoveFeed log={state.log} />
      <header className="flex items-center justify-between gap-3 px-3 py-3 sm:px-5">
        <div className="min-w-0">
          <p className="font-display text-[11px] tracking-[0.28em] text-brass">SWIFT HAND</p>
          <p className="truncate text-xs text-muted-foreground">{state.lastEvent}</p>
        </div>
        <div className="flex items-center gap-1">
          <HowToPlay />
          <Button
            variant="ghost"
            size="icon"
            aria-label={mute ? "Unmute" : "Mute"}
            onClick={() => {
              const next = !mute;
              setMute(next);
              setMuted(next);
            }}
          >
            {mute ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </Button>
          {onLeave && (
            <Button variant="ghost" size="sm" onClick={onLeave}>
              Leave
            </Button>
          )}
        </div>
      </header>

      <div className="flex flex-wrap items-end justify-center gap-4 px-3 pb-2 sm:gap-8">
        {opponents.map((p) => (
          <div key={p.id} data-seat={p.id} className={cn("flex flex-col items-center gap-1", bounceSeat === p.id && "hand-bounce")}>
            <CardFan count={p.hand.length} />
            <p
              className={cn(
                "text-xs font-medium",
                actor?.id === p.id ? "text-brass" : "text-ivory",
                p.folded && "text-muted-foreground line-through",
              )}
            >
              {p.name}
              {p.kind === "bot" ? " · house" : ""}
            </p>
            <p className="tabular-nums text-[11px] text-muted-foreground">
              {p.goneOut ? `Place ${p.placement}` : p.folded ? "folded" : `${p.hand.length} cards`}
            </p>
          </div>
        ))}
      </div>

      <div className="relative flex flex-1 flex-col items-center justify-center px-3 py-2">
        <div className="mb-3 flex items-center gap-2 text-[11px] tracking-wide text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            Suit
            <SuitPip suit={playSuit(state)} className="size-3.5" />
            {suitName(playSuit(state))}
          </span>
          <span className="inline-flex items-center gap-1">
            {state.direction === 1 ? <ArrowLeftRight className="size-3.5" /> : <RotateCcw className="size-3.5" />}
            {state.direction === 1 ? "clockwise" : "reverse"}
          </span>
          {state.pendingDebt > 0 && (
            <Badge className="border-crimson/40 bg-crimson/15 text-ivory">Debt {state.pendingDebt}</Badge>
          )}
        </div>

        <div className="flex items-end gap-5">
          <div className="flex flex-col items-center gap-1" data-draw-pile>
            <PlayingCard face="down" size="md" />
            <span className="tabular-nums text-[11px] text-muted-foreground">{state.drawPile.length}</span>
          </div>
          <div className={cn("flex flex-col items-center gap-1", pilePulse > 0 && "pile-bounce")} data-discard-pile key={pilePulse}>
            {displayTop ? (
              <PlayingCard card={displayTop} size="lg" />
            ) : (
              <div className="size-24 rounded-[10px] border border-dashed border-border" />
            )}
            <span className="text-[11px] text-muted-foreground">table</span>
          </div>
        </div>

        {state.phase === "pick-suit" && mine && (
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {SUITS.map((suit) => (
              <Button key={suit} variant="brass" onClick={() => onAction({ type: "name-suit", suit })}>
                <SuitPip suit={suit} className="size-4" />
                {suitName(suit)}
              </Button>
            ))}
          </div>
        )}

        {state.phase === "queen-prompt" && mine && (
          <div className="mt-4 flex gap-2">
            <Button variant="brass" onClick={() => onAction({ type: "cancel-hang" })}>
              Cover her
            </Button>
            <Button variant="outline" onClick={() => onAction({ type: "confirm-hang" })}>
              Leave her hanging
            </Button>
          </div>
        )}

        {state.phase === "bounce-prompt" && mine && (
          <div className="mt-4 flex gap-2">
            <Button variant="brass" onClick={() => onAction({ type: "cancel-hang" })}>
              Keep dumping
            </Button>
            <Button variant="outline" onClick={() => onAction({ type: "confirm-hang" })}>
              Hang it
            </Button>
          </div>
        )}
      </div>

      <section className="px-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:px-4">
        <div className="mx-auto flex max-w-5xl flex-col gap-3 rounded-[28px] border border-border bg-surface/80 p-3 sm:p-4">
          <div className="flex items-center justify-between gap-2">
            <p className={cn("text-sm font-medium", waitingOnMe ? "text-brass" : "text-muted-foreground")}>
              {self.name}
              {waitingOnMe ? " — your dump" : actor ? ` — waiting on ${actor.name}` : ""}
            </p>
            <div className="flex items-center gap-2">
              <div className="flex rounded-[var(--radius-sm)] border border-border p-0.5">
                <Button
                  size="sm"
                  variant={handSort === "suit" ? "brass" : "ghost"}
                  className="h-7 px-2 text-[11px]"
                  onClick={() => setSort("suit")}
                >
                  Suit
                </Button>
                <Button
                  size="sm"
                  variant={handSort === "rank" ? "brass" : "ghost"}
                  className="h-7 px-2 text-[11px]"
                  onClick={() => setSort("rank")}
                >
                  Rank
                </Button>
              </div>
              <p className="tabular-nums text-xs text-muted-foreground">{self.hand.length} in hand</p>
            </div>
          </div>

          <div
            className={cn(
              "hand-fan flex min-h-[160px] items-end justify-center overflow-x-auto px-2 pt-9",
              bounceSeat === selfId && "hand-bounce",
            )}
            data-self-hand
          >
            {shownHand.map((card, i) => {
              const selected = selection.some((c) => c.id === card.id);
              const dim = selection.length > 0 && !selected && !legalToAdd(card);
              const order = selection.findIndex((c) => c.id === card.id);
              const prevSelected =
                i > 0 && selection.some((c) => c.id === shownHand[i - 1]!.id);
              const overlap = selected || prevSelected ? -6 : -24;
              return (
                <div
                  key={card.id}
                  data-card-id={card.id}
                  className={cn(
                    "relative shrink-0 transition-transform duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
                    selected && "-translate-y-6",
                    hiddenIds.has(card.id) && "opacity-0",
                  )}
                  style={{ marginLeft: i === 0 ? 0 : overlap, zIndex: i }}
                >
                  <PlayingCard
                    card={card}
                    size="md"
                    selected={selected}
                    dimmed={dim}
                    onClick={() => toggleCard(card)}
                  />
                  {selected && (
                    <span className="pointer-events-none absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brass px-1.5 text-[10px] font-semibold text-ink">
                      {order + 1}
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setSelection([])} disabled={!selection.length}>
              Clear
            </Button>
            <Button variant="secondary" onClick={pickup} disabled={!mine || state.phase !== "turn" || playQueue.length > 0}>
              {state.pendingDebt > 0 ? `Pick up ${state.pendingDebt}` : "Pick up"}
            </Button>
            <Button
              variant="brass"
              onClick={() => dump()}
              disabled={!mine || state.phase !== "turn" || selection.length === 0 || playQueue.length > 0}
            >
              Dump{selection.length ? ` ${selection.length}` : ""}
            </Button>
          </div>

          {online && (
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (!chat.trim()) return;
                onAction({ type: "chat", playerId: selfId, text: chat });
                setChat("");
              }}
            >
              <input
                value={chat}
                onChange={(e) => setChat(e.target.value)}
                placeholder="Say something at the table"
                className="h-10 flex-1 rounded-[var(--radius-sm)] border border-border bg-felt px-3 text-sm"
              />
              <Button type="submit" size="sm" variant="outline">
                Send
              </Button>
            </form>
          )}

          {state.chat.length > 0 && (
            <ol className="max-h-16 space-y-0.5 overflow-y-auto text-xs text-muted-foreground">
              {state.chat.slice(-6).map((line) => (
                <li key={line.id}>
                  <span className="text-ivory">{line.name}:</span> {line.text}
                </li>
              ))}
            </ol>
          )}
        </div>
      </section>

      {state.phase === "hand-over" && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-md rounded-[28px] border border-brass/40 bg-surface p-6">
            <GoldBar kicker="Hand closed" subtitle="Places are locked until rematch." />
            <ol className="mt-5 space-y-2">
              {state.placements.map((id, i) => {
                const p = state.players.find((x) => x.id === id);
                return (
                  <li key={id} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{i === 0 ? "First seat" : `Place ${i + 1}`}</span>
                    <span>{p?.name ?? id}</span>
                  </li>
                );
              })}
            </ol>
            <div className="mt-5 flex flex-col gap-2">
              {online && state.players.filter((p) => p.kind === "human" && p.connected).length < 2 ? (
                <p className="text-sm text-muted-foreground">No rematch — you are the last person in the room.</p>
              ) : (
                <Button variant="brass" onClick={() => onAction({ type: "rematch", playerId: selfId })}>
                  {self.rematchReady ? "Waiting on the table" : "Rematch"}
                </Button>
              )}
              {onLeave && (
                <Button variant="ghost" onClick={onLeave}>
                  Back
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
      <SequentialFlights step={playQueue[0] ?? null} onDone={finishStep} />
    </div>
  );
}

export function LobbyPanel({
  state,
  selfId,
  onAction,
  onStart,
}: {
  state: GameState;
  selfId: string;
  onAction: (action: GameAction) => void;
  onStart: () => void;
}) {
  const isHost = state.hostId === selfId;
  return (
    <div className="felt-table flex min-h-dvh flex-col items-center px-4 py-10">
      <GoldBar kicker={`Room ${state.roomCode}`} subtitle="Chat is in the lobby. The host starts, or the table fills." />
      <div className="mt-8 w-full max-w-md rounded-[28px] border border-border bg-surface/90 p-5">
        <p className="text-xs tracking-wide text-muted-foreground">
          Seats {state.players.length} / {state.seatTarget}
        </p>
        <ul className="mt-3 space-y-2">
          {state.players.map((p) => (
            <li key={p.id} className="flex items-center justify-between text-sm">
              <span>
                {p.name}
                {p.id === state.hostId ? " · host" : ""}
              </span>
              <span className={p.connected ? "text-brass" : "text-muted-foreground"}>
                {p.connected ? "seated" : "away"}
              </span>
            </li>
          ))}
        </ul>
        {isHost && (
          <Button className="mt-5 w-full" variant="brass" onClick={onStart} disabled={state.players.length < 2}>
            Start early
          </Button>
        )}
        {!isHost && <p className="mt-5 text-sm text-muted-foreground">Waiting on the host.</p>}
        <ol className="mt-4 max-h-28 space-y-1 overflow-y-auto text-xs text-muted-foreground">
          {state.chat.slice(-8).map((line) => (
            <li key={line.id}>
              <span className="text-ivory">{line.name}:</span> {line.text}
            </li>
          ))}
        </ol>
        <ChatBox
          onSend={(text) => onAction({ type: "chat", playerId: selfId, text })}
        />
      </div>
    </div>
  );
}

function ChatBox({ onSend }: { onSend: (text: string) => void }) {
  const [text, setText] = useState("");
  return (
    <form
      className="mt-3 flex gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!text.trim()) return;
        onSend(text);
        setText("");
      }}
    >
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Lobby chat"
        className="h-10 flex-1 rounded-[var(--radius-sm)] border border-border bg-felt px-3 text-sm"
      />
      <Button type="submit" size="sm" variant="outline">
        Send
      </Button>
    </form>
  );
}
