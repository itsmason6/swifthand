import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { ArrowLeftRight, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { PlayingCard, CardFan } from "@/components/playing-card";
import { SuitPip } from "@/components/suit-pip";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GoldBar } from "@/components/gold-bar";
import { HowToPlay } from "@/components/how-to-play";
import { MoveFeed } from "@/components/move-feed";
import { TableChat } from "@/components/table-chat";
import {
  SequentialFlights,
  dumpSteps,
  fallbackBox,
  measure,
  pickupSteps,
  type Box,
  type PlayStep,
} from "@/components/card-flight";
import { canFollow, canPlayFirst, currentPlayer, playSuit, stillInPlayers, topCard } from "@/game/rules.ts";
import { isJoker, suitName } from "@/game/cards.ts";
import type { Card, GameAction, GameState, Suit } from "@/game/types.ts";
import { cn } from "@/lib/utils";
import { isMuted, setMuted, sfxPlay, unlockAudio } from "@/audio/sfx.ts";

const SUITS: Suit[] = ["spades", "hearts", "diamonds", "clubs"];
const SUIT_ORDER: Record<Suit, number> = { spades: 0, hearts: 1, diamonds: 2, clubs: 3 };
type HandSort = "suit" | "rank";

function rankValue(card: Card): number {
  if (card.rank === "joker") return 15;
  return card.rank;
}

function sortHand(hand: Card[], mode: HandSort): Card[] {
  const copy = hand.slice();
  if (mode === "suit") {
    copy.sort((a, b) => {
      if (isJoker(a) || isJoker(b)) {
        if (isJoker(a) && isJoker(b)) return (a.jokerColor === "red" ? 1 : 0) - (b.jokerColor === "red" ? 1 : 0);
        return isJoker(a) ? 1 : -1;
      }
      const s = SUIT_ORDER[a.suit] - SUIT_ORDER[b.suit];
      if (s) return s;
      return rankValue(a) - rankValue(b);
    });
  } else {
    copy.sort((a, b) => {
      const r = rankValue(a) - rankValue(b);
      if (r) return r;
      return SUIT_ORDER[a.suit] - SUIT_ORDER[b.suit];
    });
  }
  return copy;
}

function opponentOrder(state: GameState, selfSeat: number) {
  const others = stillInPlayers(state).filter((p) => p.seat !== selfSeat);
  const folded = state.players.filter((p) => p.seat !== selfSeat && (p.folded || p.goneOut));
  return [...others, ...folded];
}

export function GameTable({
  state,
  selfId,
  onAction,
  onLeave,
  online,
}: {
  state: GameState;
  selfId: string;
  onAction: (action: GameAction) => void;
  onLeave?: () => void;
  online?: boolean;
}) {
  const self = state.players.find((p) => p.id === selfId) ?? state.players[0]!;
  const actor = currentPlayer(state);
  const mine = actor?.id === self.id;
  const top = topCard(state);
  const [selection, setSelection] = useState<Card[]>([]);
  const [mute, setMute] = useState(isMuted());
  const [playQueue, setPlayQueue] = useState<PlayStep[]>([]);
  const [heldTop, setHeldTop] = useState<Card | null>(null);
  const [hiddenIds, setHiddenIds] = useState<Set<string>>(new Set());
  const [bounceSeat, setBounceSeat] = useState<string | null>(null);
  const [pilePulse, setPilePulse] = useState(0);
  const cardRects = useRef(new Map<string, Box>());
  const prevLogIds = useRef<string[] | null>(null);
  const prevHandIds = useRef(new Set<string>());
  const [handSort, setHandSort] = useState<HandSort>(() => {
    try {
      return localStorage.getItem("swift-hand-sort") === "rank" ? "rank" : "suit";
    } catch {
      return "suit";
    }
  });

  const opponents = opponentOrder(state, self.seat);

  useEffect(() => {
    const ids = new Set(self.hand.map((c) => c.id));
    setSelection((s) => {
      const next = s.filter((c) => ids.has(c.id));
      return next.length === s.length ? s : next;
    });
  }, [self.hand]);

  const ctx = { stillIn: stillInPlayers(state).filter((p) => !p.goneOut).length };
  const shownHand = sortHand(self.hand, handSort);

  function setSort(mode: HandSort) {
    setHandSort(mode);
    try {
      localStorage.setItem("swift-hand-sort", mode);
    } catch {
      /* ignore */
    }
  }

  useLayoutEffect(() => {
    const recordRects = () => {
      const next = new Map<string, Box>();
      document.querySelectorAll<HTMLElement>("[data-card-id]").forEach((el) => {
        const id = el.dataset.cardId;
        const box = measure(el);
        if (id && box) next.set(id, box);
      });
      cardRects.current = next;
    };

    if (prevLogIds.current === null) {
      prevLogIds.current = state.log.map((l) => l.id);
      prevHandIds.current = new Set(self.hand.map((c) => c.id));
      recordRects();
      return;
    }

    const seen = new Set(prevLogIds.current);
    const fresh = state.log.filter((l) => (l.kind === "dump" || l.kind === "pickup") && !seen.has(l.id));
    prevLogIds.current = state.log.map((l) => l.id);

    const draw = measure(document.querySelector("[data-draw-pile]"));
    const table = measure(document.querySelector("[data-discard-pile]"));
    const selfHand = measure(document.querySelector("[data-self-hand]"));
    const spawned: PlayStep[] = [];
    const hide: string[] = [];
    const gained = self.hand.filter((c) => !prevHandIds.current.has(c.id));
    prevHandIds.current = new Set(self.hand.map((c) => c.id));

    for (const line of fresh) {
      const who = line.playerId ?? state.players.find((p) => p.name === line.playerName)?.id;
      const minePlay = who === selfId;
      const seatBox = measure(document.querySelector(`[data-seat="${who ?? ""}"]`));

      if (line.kind === "dump" && line.cards?.length && table) {
        if (minePlay) hide.push(...line.cards.map((c) => c.id));
        spawned.push(
          ...dumpSteps(
            line.cards,
            (card) => {
              if (minePlay) return cardRects.current.get(card.id) ?? fallbackBox(selfHand);
              return fallbackBox(seatBox ?? selfHand);
            },
            table,
          ),
        );
      }

      if (line.kind === "pickup" && draw) {
        const dest = minePlay ? fallbackBox(selfHand, 80, 116) : fallbackBox(seatBox, 42, 61);
        const faceCards = minePlay ? gained : undefined;
        if (minePlay) hide.push(...gained.map((c) => c.id));
        spawned.push(...pickupSteps(line.count ?? Math.max(gained.length, 1), faceCards, draw, dest, minePlay));
      }
    }

    if (spawned.length) {
      setPlayQueue((q) => [...q, ...spawned]);
      const who = fresh.find((l) => l.playerId)?.playerId;
      if (who) {
        setBounceSeat(who);
        window.setTimeout(() => setBounceSeat((s) => (s === who ? null : s)), 340);
      }
    } else if (state.phase === "animating") {
      onAction({ type: "resolve-play" });
    }
    if (hide.length) setHiddenIds((s) => new Set([...s, ...hide]));
    recordRects();
  }, [state.log, self.hand, selfId, state.players]);

  function landStep(step: PlayStep) {
    if (step.landCard) {
      setHeldTop(step.landCard);
      setPilePulse((n) => n + 1);
    }
  }

  function finishStep(_step: PlayStep) {
    setPlayQueue((q) => {
      const next = q.slice(1);
      if (next.length === 0) {
        setHiddenIds(new Set());
        queueMicrotask(() => onAction({ type: "resolve-play" }));
      }
      return next;
    });
  }

  useEffect(() => {
    const step = playQueue[0];
    if (!step) return;
    if (step.landCard) sfxPlay.place();
    else sfxPlay.pickup();
  }, [playQueue[0]?.id]);

  useEffect(() => {
    if (!pilePulse) return;
    const el = document.querySelector("[data-discard-pile]");
    if (!(el instanceof HTMLElement)) return;
    el.classList.remove("pile-bounce");
    void el.offsetWidth;
    el.classList.add("pile-bounce");
  }, [pilePulse]);

  const inFlight = playQueue.length > 0 || state.phase === "animating";
  const displayTop = inFlight ? (heldTop ?? top) : top;

  function legalToAdd(card: Card): boolean {
    if (!mine || state.phase === "hand-over" || state.phase === "lobby" || state.phase === "animating") return false;
    if (state.phase === "pick-suit") return false;
    if (selection.length === 0) return canPlayFirst(card, state);
    return canFollow(selection[selection.length - 1]!, card, ctx);
  }

  function toggleCard(card: Card) {
    unlockAudio();
    if (selection.length && selection[selection.length - 1]!.id === card.id) {
      setSelection((s) => s.slice(0, -1));
      return;
    }
    if (selection.some((c) => c.id === card.id)) return;
    if (!legalToAdd(card)) {
      sfxPlay.error();
      return;
    }
    sfxPlay.place();
    setSelection((s) => [...s, card]);
  }

  function dump(forceHang = false) {
    if (!selection.length) return;
    onAction({ type: "dump", cardIds: selection.map((c) => c.id), forceHang });
  }

  function pickup() {
    onAction({ type: "pickup" });
    setSelection([]);
  }

  const waitingOnMe =
    mine &&
    playQueue.length === 0 &&
    state.phase !== "animating" &&
    (state.phase === "turn" ||
      state.phase === "queen-prompt" ||
      state.phase === "bounce-prompt" ||
      state.phase === "pick-suit");

  const turnLabel = (() => {
    if (state.phase === "hand-over") return "Hand closed";
    if (state.phase === "animating") return "Cards in play…";
    if (waitingOnMe && state.phase === "pick-suit") return "Your turn — name the suit";
    if (waitingOnMe && state.phase === "queen-prompt") return "Your turn — cover the Queen?";
    if (waitingOnMe && state.phase === "bounce-prompt") return "Your turn — keep dumping?";
    if (waitingOnMe) return "Your turn — dump or pick up";
    if (actor) return `${actor.name} to play`;
    return state.lastEvent;
  })();

  return (
    <div className="felt-table relative flex min-h-dvh flex-col overflow-hidden">
      <MoveFeed log={state.log} />
      <header className="flex items-center justify-between gap-3 px-3 py-3 sm:px-5">
        <div className="min-w-0">
          <p className="font-display text-[11px] tracking-[0.28em] text-brass">SWIFT HAND</p>
        </div>
        <div className="flex items-center gap-1">
          <HowToPlay />
          <Button
            variant="ghost"
            size="icon"
            aria-label={mute ? "Unmute" : "Mute"}
            onClick={() => {
              const next = !mute;
              setMute(next);
              setMuted(next);
            }}
          >
            {mute ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </Button>
          {onLeave && (
            <Button variant="ghost" size="sm" onClick={onLeave}>
              Leave
            </Button>
          )}
        </div>
      </header>
      <div
        className={cn(
          "mx-3 mb-2 rounded-[14px] border px-3 py-2 text-center sm:mx-5",
          waitingOnMe
            ? "turn-yours border-brass/70 bg-brass/15 text-brass"
            : "border-border bg-surface/80 text-ivory",
        )}
      >
        <p className="font-display text-sm tracking-[0.14em] sm:text-base">{turnLabel}</p>
      </div>

      <div className="flex flex-wrap items-start justify-center gap-6 px-3 pb-2 sm:gap-10">
        {opponents.map((p) => (
          <div key={p.id} data-seat={p.id} className={cn("flex min-w-[7rem] flex-col items-center gap-1 rounded-[16px] px-2 py-1", bounceSeat === p.id && "hand-bounce", actor?.id === p.id && !mine && "ring-2 ring-brass/80 bg-brass/10")}>
            <p
              className={cn(
                "relative z-10 max-w-[9rem] truncate text-center text-xs font-semibold drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]",
                actor?.id === p.id ? "text-brass" : "text-ivory",
                p.folded && "text-muted-foreground line-through",
              )}
            >
              {p.name}
              {p.kind === "bot" ? " · house" : ""}
            </p>
            <p className="relative z-10 tabular-nums text-[11px] text-muted-foreground">
              {p.goneOut ? `Place ${p.placement}` : p.folded ? "folded" : `${p.hand.length} cards`}
            </p>
            <CardFan count={p.hand.length} />
          </div>
        ))}
      </div>

      <div className="relative flex flex-1 flex-col items-center justify-center px-3 py-2">
        <div className="mb-3 flex items-center gap-2 text-[11px] tracking-wide text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            Suit
            <SuitPip suit={playSuit(state)} className="size-3.5" />
            {suitName(playSuit(state))}
          </span>
          <span className="inline-flex items-center gap-1">
            {state.direction === 1 ? <ArrowLeftRight className="size-3.5" /> : <RotateCcw className="size-3.5" />}
            {state.direction === 1 ? "clockwise" : "reverse"}
          </span>
          {state.pendingDebt > 0 && (
            <Badge className="border-crimson/40 bg-crimson/15 text-ivory">Debt {state.pendingDebt}</Badge>
          )}
        </div>

        <div className="flex items-end gap-5">
          <div className="flex flex-col items-center gap-1">
            <div data-draw-pile>
              <PlayingCard face="down" size="md" />
            </div>
            <span className="tabular-nums text-[11px] text-muted-foreground">{state.drawPile.length}</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div data-discard-pile>
              {displayTop ? (
                <PlayingCard card={displayTop} size="lg" />
              ) : (
                <div className="size-24 rounded-[10px] border border-dashed border-border" />
              )}
            </div>
            <span className="text-[11px] text-muted-foreground">table</span>
          </div>
        </div>

        {state.phase === "pick-suit" && mine && (
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {SUITS.map((suit) => (
              <Button key={suit} variant="brass" onClick={() => onAction({ type: "name-suit", suit })}>
                <SuitPip suit={suit} className="size-4" />
                {suitName(suit)}
              </Button>
            ))}
          </div>
        )}

        {state.phase === "queen-prompt" && mine && (
          <div className="mt-4 flex gap-2">
            <Button variant="brass" onClick={() => onAction({ type: "cancel-hang" })}>
              Cover her
            </Button>
            <Button variant="outline" onClick={() => onAction({ type: "confirm-hang" })}>
              Leave her hanging
            </Button>
          </div>
        )}

        {state.phase === "bounce-prompt" && mine && (
          <div className="mt-4 flex gap-2">
            <Button variant="brass" onClick={() => onAction({ type: "cancel-hang" })}>
              Keep dumping
            </Button>
            <Button variant="outline" onClick={() => onAction({ type: "confirm-hang" })}>
              Hang it
            </Button>
          </div>
        )}
      </div>

      <section className="px-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:px-4">
        <div
          className={cn(
            "relative z-[8] mx-auto flex max-w-5xl flex-col gap-3 rounded-[28px] border bg-surface/80 p-3 sm:p-4",
            waitingOnMe ? "border-brass shadow-[0_0_0_1px_rgba(201,162,39,0.35)]" : "border-border",
          )}
        >
          <div className="flex items-center justify-between gap-2">
            <p className={cn("text-sm font-medium", waitingOnMe ? "text-brass" : "text-muted-foreground")}>
              {self.name}
              {waitingOnMe ? " — your dump" : actor ? ` — waiting on ${actor.name}` : ""}
            </p>
            <div className="flex items-center gap-2">
              <div className="flex rounded-[var(--radius-sm)] border border-border p-0.5">
                <Button
                  size="sm"
                  variant={handSort === "suit" ? "brass" : "ghost"}
                  className="h-7 px-2 text-[11px]"
                  onClick={() => setSort("suit")}
                >
                  Suit
                </Button>
                <Button
                  size="sm"
                  variant={handSort === "rank" ? "brass" : "ghost"}
                  className="h-7 px-2 text-[11px]"
                  onClick={() => setSort("rank")}
                >
                  Rank
                </Button>
              </div>
              <p className="tabular-nums text-xs text-muted-foreground">{self.hand.length} in hand</p>
            </div>
          </div>

          <div
            className={cn("overflow-x-auto overscroll-x-contain [-webkit-overflow-scrolling:touch]", bounceSeat === selfId && "hand-bounce")}
            data-self-hand
          >
            <div className="hand-fan flex w-max min-w-full items-end justify-center px-5 pt-9 pb-1">
            {shownHand.map((card, i) => {
              const selected = selection.some((c) => c.id === card.id);
              const dim = selection.length > 0 && !selected && !legalToAdd(card);
              const order = selection.findIndex((c) => c.id === card.id);
              const prevSelected =
                i > 0 && selection.some((c) => c.id === shownHand[i - 1]!.id);
              const many = shownHand.length >= 5;
              const overlap = selected || prevSelected ? -4 : many ? -14 : -22;
              return (
                <div
                  key={card.id}
                  data-card-id={card.id}
                  className={cn(
                    "relative shrink-0 transition-transform duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
                    selected && "-translate-y-6",
                    hiddenIds.has(card.id) && "opacity-0",
                  )}
                  style={{ marginLeft: i === 0 ? 0 : overlap, zIndex: selected ? 40 : i }}
                >
                  <PlayingCard
                    card={card}
                    size={many ? "sm" : "md"}
                    selected={selected}
                    dimmed={dim}
                    onClick={() => toggleCard(card)}
                  />
                  {selected && (
                    <span className="pointer-events-none absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brass px-1.5 text-[10px] font-semibold text-ink">
                      {order + 1}
                    </span>
                  )}
                </div>
              );
            })}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setSelection([])} disabled={!selection.length}>
              Clear
            </Button>
            <Button variant="secondary" onClick={pickup} disabled={!mine || state.phase !== "turn" || playQueue.length > 0}>
              {state.pendingDebt > 0 ? `Pick up ${state.pendingDebt}` : "Pick up"}
            </Button>
            <Button
              variant="brass"
              onClick={() => dump()}
              disabled={!mine || state.phase !== "turn" || selection.length === 0 || playQueue.length > 0}
            >
              Dump{selection.length ? ` ${selection.length}` : ""}
            </Button>
          </div>

          {online && (
            <TableChat
              compact
              className="mt-3 w-full"
              lines={state.chat}
              onSend={(text) => onAction({ type: "chat", playerId: selfId, text })}
            />
          )}
        </div>
      </section>

      {state.phase === "hand-over" && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-md rounded-[28px] border border-brass/40 bg-surface p-6">
            <GoldBar kicker="Hand closed" subtitle="Places are locked until rematch." />
            <ol className="mt-5 space-y-2">
              {state.placements.map((id, i) => {
                const p = state.players.find((x) => x.id === id);
                return (
                  <li key={id} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{i === 0 ? "First seat" : `Place ${i + 1}`}</span>
                    <span>{p?.name ?? id}</span>
                  </li>
                );
              })}
            </ol>
            <div className="mt-5 flex flex-col gap-2">
              {online && state.players.filter((p) => p.kind === "human" && p.connected).length < 2 ? (
                <p className="text-sm text-muted-foreground">No rematch — you are the last person in the room.</p>
              ) : (
                <Button variant="brass" onClick={() => onAction({ type: "rematch", playerId: selfId })}>
                  {self.rematchReady ? "Waiting on the table" : "Rematch"}
                </Button>
              )}
              {onLeave && (
                <Button variant="ghost" onClick={onLeave}>
                  Back
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
      <SequentialFlights step={playQueue[0] ?? null} onLand={landStep} onDone={finishStep} />
    </div>
  );
}

export function LobbyPanel({
  state,
  selfId,
  onAction,
  onStart,
}: {
  state: GameState;
  selfId: string;
  onAction: (action: GameAction) => void;
  onStart: () => void;
}) {
  const isHost = state.hostId === selfId;
  return (
    <div className="felt-table flex min-h-dvh flex-col items-center px-4 py-10">
      <GoldBar kicker={`Room ${state.roomCode}`} subtitle="Chat is in the lobby. The host starts, or the table fills." />
      <div className="mt-8 w-full max-w-md rounded-[28px] border border-border bg-surface/90 p-5">
        <p className="text-xs tracking-wide text-muted-foreground">
          Seats {state.players.length} / {state.seatTarget}
        </p>
        <ul className="mt-3 space-y-2">
          {state.players.map((p) => (
            <li key={p.id} className="flex items-center justify-between text-sm">
              <span>
                {p.name}
                {p.id === state.hostId ? " · host" : ""}
              </span>
              <span className={p.connected ? "text-brass" : "text-muted-foreground"}>
                {p.connected ? "seated" : "away"}
              </span>
            </li>
          ))}
        </ul>
        {isHost && (
          <Button className="mt-5 w-full" variant="brass" onClick={onStart} disabled={state.players.length < 2}>
            Start early
          </Button>
        )}
        {!isHost && <p className="mt-5 text-sm text-muted-foreground">Waiting on the host.</p>}
        <TableChat
          className="mt-5"
          lines={state.chat}
          placeholder="Lobby chat"
          onSend={(text) => onAction({ type: "chat", playerId: selfId, text })}
        />
      </div>
    </div>
  );
}

