import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { CARD_BACK_SRC, cardImageSrc, preloadCardImage } from "@/game/cards.ts";
import type { Card } from "@/game/types.ts";

export type Box = { x: number; y: number; w: number; h: number };

export type PlayStep = {
  id: string;
  src: string;
  from: Box;
  to: Box;
  landCard?: Card;
};

export const STEP_MS = 420;
export const LAND_HOLD_MS = 700;
export const PICK_HOLD_MS = 160;

export function measure(el: Element | null | undefined): Box | null {
  if (!el) return null;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return null;
  return { x: r.left, y: r.top, w: r.width, h: r.height };
}

export function fallbackBox(anchor: Box | null, w = 72, h = 104): Box {
  if (anchor) return { x: anchor.x + Math.max(0, (anchor.w - w) / 2), y: anchor.y, w, h };
  return { x: Math.max(16, window.innerWidth / 2 - w / 2), y: Math.max(80, window.innerHeight / 3), w, h };
}

export function dumpSteps(cards: Card[], fromFor: (card: Card, i: number) => Box, to: Box): PlayStep[] {
  return cards.map((card, i) => {
    preloadCardImage(card);
    return {
      id: `dump-${card.id}-${i}-${Math.random().toString(36).slice(2, 7)}`,
      src: cardImageSrc(card),
      from: fromFor(card, i),
      to,
      landCard: card,
    };
  });
}

export function pickupSteps(count: number, cards: Card[] | undefined, from: Box, to: Box, faceUp: boolean): PlayStep[] {
  const n = Math.max(1, Math.min(count, 12));
  return Array.from({ length: n }, (_, i) => {
    const card = cards?.[i];
    return {
      id: `pick-${i}-${Math.random().toString(36).slice(2, 7)}`,
      src: faceUp && card ? cardImageSrc(card) : CARD_BACK_SRC,
      from,
      to,
    };
  });
}

function flightRoot(): HTMLElement {
  let el = document.getElementById("swift-hand-flights");
  if (!(el instanceof HTMLElement)) {
    el = document.createElement("div");
    el.id = "swift-hand-flights";
    el.setAttribute("aria-hidden", "true");
    el.style.cssText = "position:fixed;inset:0;z-index:10000;pointer-events:none;";
    document.body.appendChild(el);
  }
  return el;
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function easeOutBack(t: number) {
  const c = 1.70158;
  const x = t - 1;
  return 1 + (c + 1) * x * x * x + c * x * x;
}

function Flyer({
  step,
  onLand,
  onDone,
}: {
  step: PlayStep;
  onLand?: () => void;
  onDone: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const done = useRef(onDone);
  const land = useRef(onLand);
  done.current = onDone;
  land.current = onLand;

  useEffect(() => {
    const el = ref.current;
    const img = imgRef.current;
    if (!el) return;
    const { from, to } = step;
    let raf = 0;
    let hold = 0;
    let cancelled = false;
    let landed = false;

    const settle = () => {
      if (cancelled) return;
      el.style.transform = `translate(${to.x}px, ${to.y}px)`;
      el.style.width = `${to.w}px`;
      el.style.height = `${to.h}px`;
      if (!landed) {
        landed = true;
        land.current?.();
      }
      const linger = step.landCard ? LAND_HOLD_MS : PICK_HOLD_MS;
      hold = window.setTimeout(() => {
        if (!cancelled) done.current();
      }, linger);
    };

    const run = () => {
      if (cancelled || !el) return;
      el.style.opacity = "1";
      const lift = Math.min(90, 36 + Math.abs(to.y - from.y) * 0.18);
      const t0 = performance.now();
      const tick = (now: number) => {
        if (cancelled) return;
        const t = Math.min(1, (now - t0) / STEP_MS);
        const e = easeOutBack(t);
        const x = lerp(from.x, to.x, e);
        const y = lerp(from.y, to.y, e) - Math.sin(t * Math.PI) * lift;
        const w = lerp(from.w, to.w, e);
        const h = lerp(from.h, to.h, e);
        const pop = t > 0.82 ? 1 + Math.sin(((t - 0.82) / 0.18) * Math.PI) * 0.08 : 1;
        el.style.transform = `translate(${x}px, ${y}px) scale(${pop})`;
        el.style.width = `${w}px`;
        el.style.height = `${h}px`;
        if (t < 1) raf = requestAnimationFrame(tick);
        else settle();
      };
      raf = requestAnimationFrame(tick);
    };

    const ready = img?.complete && img.naturalWidth > 0
      ? Promise.resolve()
      : img?.decode?.() ?? Promise.resolve();
    void Promise.resolve(ready).then(run).catch(run);

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      window.clearTimeout(hold);
    };
  }, [step]);

  const { from } = step;
  return createPortal(
    <div
      ref={ref}
      className="pointer-events-none absolute overflow-hidden rounded-[10px] shadow-[0_18px_36px_rgba(0,0,0,0.55)]"
      style={{
        zIndex: 2,
        transformOrigin: "top left",
        transform: `translate(${from.x}px, ${from.y}px)`,
        width: from.w,
        height: from.h,
        opacity: 0,
        background: step.landCard ? "#f3ecdc" : "#12100e",
      }}
    >
      <img
        ref={imgRef}
        src={step.src}
        alt=""
        draggable={false}
        className="h-full w-full object-contain"
      />
    </div>,
    flightRoot(),
  );
}

export function SequentialFlights({
  step,
  onLand,
  onDone,
}: {
  step: PlayStep | null;
  onLand?: (step: PlayStep) => void;
  onDone: (step: PlayStep) => void;
}) {
  if (!step || typeof document === "undefined") return null;
  return (
    <Flyer
      key={step.id}
      step={step}
      onLand={() => onLand?.(step)}
      onDone={() => onDone(step)}
    />
  );
}
