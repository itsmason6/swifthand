import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { CARD_BACK_SRC, cardImageSrc } from "@/game/cards.ts";
import type { Card } from "@/game/types.ts";

export type Box = { x: number; y: number; w: number; h: number };

export type Flight = {
  id: string;
  src: string;
  from: Box;
  to: Box;
  delay: number;
};

export function measure(el: Element | null | undefined): Box | null {
  if (!el) return null;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return null;
  return { x: r.left, y: r.top, w: r.width, h: r.height };
}

export function fallbackBox(anchor: Box | null, w = 56, h = 81): Box {
  if (anchor) return { x: anchor.x + anchor.w / 2 - w / 2, y: anchor.y + 8, w, h };
  return { x: window.innerWidth / 2 - w / 2, y: window.innerHeight / 3, w, h };
}

export function dumpFlights(cards: Card[], fromFor: (card: Card, i: number) => Box, to: Box): Flight[] {
  return cards.map((card, i) => ({
    id: `dump-${card.id}-${i}-${performance.now()}`,
    src: cardImageSrc(card),
    from: fromFor(card, i),
    to,
    delay: i * 70,
  }));
}

export function pickupFlights(count: number, cards: Card[] | undefined, from: Box, to: Box, faceUp: boolean): Flight[] {
  const n = Math.max(1, Math.min(count, 12));
  return Array.from({ length: n }, (_, i) => {
    const card = cards?.[i];
    return {
      id: `pick-${i}-${performance.now()}`,
      src: faceUp && card ? cardImageSrc(card) : CARD_BACK_SRC,
      from: { ...from, x: from.x + i * 2, y: from.y - i * 2 },
      to: { ...to, x: to.x + i * 6, y: to.y + i * 3 },
      delay: i * 55,
    };
  });
}

function prefersReduced() {
  return window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ?? false;
}

function FlyingCard({ flight, onDone }: { flight: Flight; onDone: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const done = useRef(onDone);
  done.current = onDone;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const { from, to, delay } = flight;
    const sx = to.w / Math.max(from.w, 1);
    const sy = to.h / Math.max(from.h, 1);
    const duration = prefersReduced() ? 1 : 480;
    const anim = el.animate(
      [
        { transform: `translate(${from.x}px, ${from.y}px) scale(1) rotate(0deg)`, opacity: 1 },
        {
          transform: `translate(${to.x}px, ${to.y}px) scale(${sx}, ${sy}) rotate(${from.x < to.x ? 6 : -6}deg)`,
          opacity: 1,
        },
      ],
      { duration, delay, easing: "cubic-bezier(0.22, 1, 0.36, 1)", fill: "forwards" },
    );
    anim.onfinish = () => done.current();
    return () => anim.cancel();
  }, [flight]);

  return (
    <div
      ref={ref}
      className="pointer-events-none fixed top-0 left-0 z-[90] will-change-transform"
      style={{ width: flight.from.w, height: flight.from.h, transformOrigin: "top left" }}
    >
      <img
        src={flight.src}
        alt=""
        draggable={false}
        className="h-full w-full rounded-[8px] object-cover shadow-[0_18px_40px_rgba(0,0,0,0.55)]"
      />
    </div>
  );
}

export function CardFlightLayer({
  flights,
  onDone,
}: {
  flights: Flight[];
  onDone: (id: string) => void;
}) {
  if (typeof document === "undefined" || flights.length === 0) return null;
  return createPortal(
    <>
      {flights.map((flight) => (
        <FlyingCard key={flight.id} flight={flight} onDone={() => onDone(flight.id)} />
      ))}
    </>,
    document.body,
  );
}
