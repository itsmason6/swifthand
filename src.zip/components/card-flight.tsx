import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { CARD_BACK_SRC, cardImageSrc } from "@/game/cards.ts";
import type { Card } from "@/game/types.ts";

export type Box = { x: number; y: number; w: number; h: number };

export type PlayStep = {
  id: string;
  src: string;
  from: Box;
  to: Box;
  landCard?: Card;
};

export const STEP_MS = 420;

export function measure(el: Element | null | undefined): Box | null {
  if (!el) return null;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return null;
  return { x: r.left, y: r.top, w: r.width, h: r.height };
}

export function fallbackBox(anchor: Box | null, w = 72, h = 104): Box {
  if (anchor) return { x: anchor.x + Math.max(0, (anchor.w - w) / 2), y: anchor.y, w, h };
  return { x: Math.max(16, window.innerWidth / 2 - w / 2), y: Math.max(80, window.innerHeight / 3), w, h };
}

export function dumpSteps(cards: Card[], fromFor: (card: Card, i: number) => Box, to: Box): PlayStep[] {
  return cards.map((card, i) => ({
    id: `dump-${card.id}-${i}-${Math.random().toString(36).slice(2, 7)}`,
    src: cardImageSrc(card),
    from: fromFor(card, i),
    to,
    landCard: card,
  }));
}

export function pickupSteps(count: number, cards: Card[] | undefined, from: Box, to: Box, faceUp: boolean): PlayStep[] {
  const n = Math.max(1, Math.min(count, 12));
  return Array.from({ length: n }, (_, i) => {
    const card = cards?.[i];
    return {
      id: `pick-${i}-${Math.random().toString(36).slice(2, 7)}`,
      src: faceUp && card ? cardImageSrc(card) : CARD_BACK_SRC,
      from,
      to,
    };
  });
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function easeOutBack(t: number) {
  const c = 1.70158;
  const x = t - 1;
  return 1 + (c + 1) * x * x * x + c * x * x;
}

function Flyer({ step, onDone }: { step: PlayStep; onDone: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const done = useRef(onDone);
  done.current = onDone;

  useEffect(() => {
    const el = ref.current;
    const img = imgRef.current;
    if (!el) return;
    const { from, to } = step;
    let raf = 0;
    let cancelled = false;

    const run = () => {
      if (cancelled || !el) return;
      el.style.opacity = "1";
      const lift = Math.min(90, 36 + Math.abs(to.y - from.y) * 0.18);
      const t0 = performance.now();
      const tick = (now: number) => {
        if (cancelled) return;
        const t = Math.min(1, (now - t0) / STEP_MS);
        const e = easeOutBack(t);
        const x = lerp(from.x, to.x, e);
        const y = lerp(from.y, to.y, e) - Math.sin(t * Math.PI) * lift;
        const w = lerp(from.w, to.w, e);
        const h = lerp(from.h, to.h, e);
        const pop = t > 0.82 ? 1 + Math.sin(((t - 0.82) / 0.18) * Math.PI) * 0.08 : 1;
        el.style.transform = `translate(${x}px, ${y}px) scale(${pop})`;
        el.style.width = `${w}px`;
        el.style.height = `${h}px`;
        if (t < 1) raf = requestAnimationFrame(tick);
        else done.current();
      };
      raf = requestAnimationFrame(tick);
    };

    const ready = img?.complete && img.naturalWidth > 0
      ? Promise.resolve()
      : img?.decode?.() ?? Promise.resolve();
    void Promise.resolve(ready).then(run).catch(run);

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
    };
  }, [step]);

  const { from } = step;
  return createPortal(
    <div
      ref={ref}
      className="pointer-events-none fixed top-0 left-0 z-[9999] overflow-hidden rounded-[10px]"
      style={{
        transformOrigin: "top left",
        transform: `translate(${from.x}px, ${from.y}px)`,
        width: from.w,
        height: from.h,
        opacity: 0,
      }}
    >
      <img
        ref={imgRef}
        src={step.src}
        alt=""
        draggable={false}
        className="h-full w-full object-cover"
      />
    </div>,
    document.body,
  );
}

export function SequentialFlights({
  step,
  onDone,
}: {
  step: PlayStep | null;
  onDone: (step: PlayStep) => void;
}) {
  if (!step || typeof document === "undefined") return null;
  return <Flyer key={step.id} step={step} onDone={() => onDone(step)} />;
}
