import type { CSSProperties } from "react";
import type { Suit } from "@/game/types.ts";
import { cn } from "@/lib/utils";

export function SuitPip({
  suit,
  className,
  style,
}: {
  suit: Suit;
  className?: string;
  style?: CSSProperties;
}) {
  const isRed = suit === "hearts" || suit === "diamonds";
  return (
    <svg
      viewBox="0 0 24 24"
      className={cn(isRed ? "pip-red" : "pip-black", className)}
      style={style}
      aria-hidden
    >
      {suit === "spades" && (
        <path
          fill="currentColor"
          d="M12 2C8.5 8 4 10.8 4 15.2 4 18.4 6.5 21 9.4 21c1.2 0 2.2-.4 2.6-1.1V22h.01v-2.1c.4.7 1.4 1.1 2.6 1.1 2.9 0 5.4-2.6 5.4-5.8C20 10.8 15.5 8 12 2z"
        />
      )}
      {suit === "hearts" && (
        <path
          fill="currentColor"
          d="M12 21S3 14.2 3 8.8C3 5.9 5.2 4 7.7 4c1.7 0 3.3.9 4.3 2.3C13 4.9 14.6 4 16.3 4 18.8 4 21 5.9 21 8.8 21 14.2 12 21 12 21z"
        />
      )}
      {suit === "diamonds" && (
        <path fill="currentColor" d="M12 2 21 12 12 22 3 12z" />
      )}
      {suit === "clubs" && (
        <path
          fill="currentColor"
          d="M12 2.2a4.2 4.2 0 0 0-1.7 8.1A4.3 4.3 0 1 0 8.2 17H11v2.8H9.4V21h5.2v-1.2H13V17h2.8a4.3 4.3 0 1 0-2.1-6.7A4.2 4.2 0 0 0 12 2.2z"
        />
      )}
    </svg>
  );
}
