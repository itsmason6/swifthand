import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export function HowToPlay() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost">How to play</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[80vh] overflow-y-auto">
        <DialogTitle className="font-display text-xl tracking-wide">The table is mean on purpose</DialogTitle>
        <DialogDescription className="mt-1 text-muted-foreground">
          Empty your hand first. Last card can still tax you.
        </DialogDescription>
        <div className="mt-5 space-y-4 text-sm leading-relaxed text-ivory/90">
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">Deal</h3>
            <p>2–6 players. 7 cards each. One starter flipped — if it is a 2, Jack, King, Queen, 7, Ace or Joker, the effect is live before anyone has a proper turn. Clockwise until a 7 reverses it.</p>
          </section>
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">A turn</h3>
            <p>Dump or pick up. Never both. The first card must match rank, the current suit, or be wild (Joker, Ace, or 2/Jack on 2/Jack). Then more cards, in order: same rank, same suit consecutive (8♥ → 7♥ → 6♥, not a skip), or a special pairing. If you cannot dump, pick up — and that is the whole turn.</p>
          </section>
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">Specials</h3>
            <ul className="list-disc space-y-1 pl-4">
              <li>2 — next picks up 2 unless they fight. Black Jack — next picks up 5. They stack on the end of a dump (King♥ → 2♥ → Jack♠ is 7). Cover them with another card and the tax dies.</li>
              <li>7 reverses only if it is the last card of the dump. A 7 that starts a run (7♦ → 6♦ → 5♦) is just a suit chain. With two still in, a last-card 7 acts like a King, and any card of that 7’s suit may follow it.</li>
              <li>Red Jack kills the debt and becomes the top card.</li>
              <li>Queen must be covered in the same dump if you can. Leave her hanging and you pick up 1. Last-card Queen does not put you out.</li>
              <li>King skips the next seat. With two still in, a last-card King bounces — you may keep dumping. A 2 or black Jack after that bounce must match the King/7’s suit, and the other seat picks up, not you.</li>
              <li>Ace starts a dump on anything. After an Ace: another Ace, or a 2 or 3 of that Ace’s suit (Ace♥ → 2♥ → 3♥, or Ace♥ → 3♥). A 3 of that suit can also drop onto the Ace (3♥ → Ace♥, or 3♥ → 2♥ → Ace♥). Last Ace names the suit, then your turn ends.</li>
              <li>Joker dumps by itself on anything, except it cannot fight a 2 / Jack pickup. You may add a Joker after a Queen, King, or 7 in the same dump (to cover her, or when a 7/King sends the turn back). Several Jokers: only the last swaps hands. Last-card Joker: you are out, no swap. Black plays as spades, red as hearts.</li>
            </ul>
          </section>
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">Winning</h3>
            <p>First empty hand wins that seat. The rest play for remaining places. If you are the last one still in, you take the table.</p>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
