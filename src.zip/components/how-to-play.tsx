import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export function HowToPlay() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost">How to play</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[80vh] overflow-y-auto">
        <DialogTitle className="font-display text-xl tracking-wide">The table is mean on purpose</DialogTitle>
        <DialogDescription className="mt-1 text-muted-foreground">
          Empty your hand first. Last card can still tax you.
        </DialogDescription>
        <div className="mt-5 space-y-4 text-sm leading-relaxed text-ivory/90">
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">Deal</h3>
            <p>2–6 players. 7 cards each. One starter flipped — if it is a 2, Jack, King, Queen, 7, Ace or Joker, the effect is live before anyone has a proper turn. Clockwise until a 7 reverses it.</p>
          </section>
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">A turn</h3>
            <p>Dump or pick up. Never both. The first card must match rank, the current suit, or be wild (Joker, Ace, or 2/Jack on 2/Jack). Then more cards, in order: same rank, same suit consecutive (8♥ → 7♥ → 6♥, not a skip), or a special pairing. If you cannot dump, pick up — and that is the whole turn.</p>
          </section>
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">Specials</h3>
            <ul className="list-disc space-y-1 pl-4">
              <li>2 — next picks up 2 unless they fight. Black Jack — next picks up 5. They stack. Two black Jacks = 10. A black Jack then a 2 = 7.</li>
              <li>Red Jack kills the debt and becomes the top card.</li>
              <li>Queen must be covered in the same dump if you can. Leave her hanging and you pick up 1. Last-card Queen does not put you out.</li>
              <li>King skips the next seat. With two still in, it bounces — you may keep dumping.</li>
              <li>7 reverses. With two still in it acts like a King.</li>
              <li>Ace starts a dump on anything. After an Ace, only another Ace. The last Ace names the suit, then your turn ends.</li>
              <li>Joker sits on anything and sets suit (black → spades, red → hearts). Several Jokers: only the last swaps hands. Last-card Joker: you are out, no swap.</li>
            </ul>
          </section>
          <section>
            <h3 className="mb-1 font-display text-sm tracking-wide text-brass">Winning</h3>
            <p>First empty hand wins that seat. The rest play for remaining places. If you are the last one still in, you take the table.</p>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
