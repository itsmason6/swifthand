import { useEffect, useState } from "react";
import { CARD_BACK_SRC, cardImageSrc, cardLabel } from "@/game/cards.ts";
import type { Card } from "@/game/types.ts";
import { cn } from "@/lib/utils";

/** Aspect matches the Byron Knoll PNG deck (500×726). */
const SIZES = {
  xs: { w: 42, h: 61, r: 5 },
  sm: { w: 56, h: 81, r: 6 },
  md: { w: 80, h: 116, r: 8 },
  lg: { w: 112, h: 162, r: 10 },
} as const;

export const CARD_PIXELS = SIZES;
export type CardSize = keyof typeof SIZES;

function CardShell({
  src,
  label,
  size,
  selected,
  dimmed,
  onClick,
  className,
  down,
}: {
  src: string;
  label: string;
  size: (typeof SIZES)[CardSize];
  selected: boolean;
  dimmed: boolean;
  onClick?: () => void;
  className?: string;
  down: boolean;
}) {
  const clickable = Boolean(onClick);
  const [shown, setShown] = useState(src);
  useEffect(() => {
    if (src === shown) return;
    let live = true;
    const im = new Image();
    im.decoding = "async";
    im.onload = () => {
      if (live) setShown(src);
    };
    im.src = src;
    if (im.complete && im.naturalWidth > 0) setShown(src);
    return () => {
      live = false;
    };
  }, [src, shown]);
  return (
    <button
      type="button"
      disabled={!clickable}
      onClick={onClick}
      className={cn(
        "playing-card",
        down ? "card-back" : "card-face",
        selected && "is-selected",
        dimmed && "is-dimmed",
        clickable && "cursor-pointer",
        className,
      )}
      style={{ width: size.w, height: size.h, borderRadius: size.r }}
      aria-label={label}
      aria-pressed={selected}
    >
      <img src={shown} alt="" draggable={false} decoding="async" />
    </button>
  );
}

export function PlayingCard({
  card,
  face = "up",
  size = "md",
  selected = false,
  dimmed = false,
  onClick,
  className,
}: {
  card?: Card;
  face?: "up" | "down";
  size?: CardSize;
  selected?: boolean;
  dimmed?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  const s = SIZES[size];

  if (!card || face === "down") {
    return (
      <CardShell
        src={CARD_BACK_SRC}
        label="Facedown card"
        size={s}
        selected={selected}
        dimmed={dimmed}
        onClick={onClick}
        className={className}
        down
      />
    );
  }

  const label = cardLabel(card);

  return (
    <CardShell
      src={cardImageSrc(card)}
      label={label}
      size={s}
      selected={selected}
      dimmed={dimmed}
      onClick={onClick}
      className={className}
      down={false}
    />
  );
}

export function CardFan({
  count,
  size = "xs",
}: {
  count: number;
  size?: CardSize;
}) {
  const n = Math.min(count, 10);
  return (
    <div className="relative h-[72px] w-[100px]">
      {Array.from({ length: n }).map((_, i) => (
        <div
          key={i}
          className="absolute left-1/2 top-0"
          style={{
            transform: `translateX(-50%) rotate(${(i - (n - 1) / 2) * 8}deg) translateY(${Math.abs(i - (n - 1) / 2) * 1.4}px)`,
            transformOrigin: "bottom center",
          }}
        >
          <PlayingCard face="down" size={size} />
        </div>
      ))}
      {count === 0 && <span className="text-[10px] text-muted-foreground">empty</span>}
    </div>
  );
}
