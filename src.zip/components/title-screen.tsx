import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { GoldBar } from "@/components/gold-bar";
import { HowToPlay } from "@/components/how-to-play";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { loadIdentity, roomCode, saveIdentity } from "@/lib/identity";
import { unlockAudio } from "@/audio/sfx.ts";

export function TitleScreen() {
  const navigate = useNavigate();
  const [identity, setIdentity] = useState({ id: "", name: "Seat" });

  useEffect(() => {
    setIdentity(loadIdentity());
  }, []);
  const [seats, setSeats] = useState(3);
  const [join, setJoin] = useState("");
  const [password, setPassword] = useState("");
  const [hostPassword, setHostPassword] = useState("");
  const [hostSeats, setHostSeats] = useState(4);

  function persistName(name: string) {
    const next = { ...identity, name: name.slice(0, 18) || "Seat" };
    setIdentity(next);
    saveIdentity(next);
  }

  return (
    <main className="felt-table relative flex min-h-dvh flex-col items-center px-4 py-10 sm:py-16">
      <GoldBar />
      <p className="mt-6 max-w-md text-center text-sm leading-relaxed text-muted-foreground">
        One 52-card pack plus two Jokers. Dump or pick up. The Queen hangs. Debt stacks. The last card can still tax you.
      </p>

      <a
        href="/downloads/swift-hand-github.zip"
        download="swift-hand-github.zip"
        className="mt-5 inline-flex w-full max-w-md items-center justify-center gap-2 rounded-[var(--radius-sm)] bg-brass px-4 py-3 text-sm font-medium text-ink shadow-[inset_0_1px_0_rgba(255,255,255,0.35)] hover:bg-brass-bright"
      >
        <Download className="size-4" />
        Download GitHub zip
      </a>
      <p className="mt-2 max-w-md text-center text-xs text-muted-foreground">
        New GitHub repo, new Railway project. Unzip, open <span className="text-ivory">swift-hand</span>, upload everything inside it (package.json at the repo root). About 40 files. Do not nest another folder. Leave Railway Root Directory blank.
      </p>

      <div className="mt-8 w-full max-w-md space-y-6 rounded-[28px] border border-border bg-surface/85 p-5 sm:p-6">
        <div className="space-y-1.5">
          <Label htmlFor="name">Your name at the table</Label>
          <Input
            id="name"
            value={identity.name}
            maxLength={18}
            onChange={(e) => persistName(e.target.value)}
          />
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-sm tracking-[0.18em] text-brass">OFFLINE</h2>
          <p className="text-xs text-muted-foreground">Same rules against the house. Good for Queen-hang and two-player bounce.</p>
          <div className="flex flex-wrap gap-2">
            {[2, 3, 4, 5, 6].map((n) => (
              <Button key={n} size="sm" variant={seats === n ? "brass" : "outline"} onClick={() => setSeats(n)}>
                {n}
              </Button>
            ))}
          </div>
          <Button
            className="w-full"
            variant="brass"
            disabled={!identity.id}
            onClick={() => {
              unlockAudio();
              void navigate({ to: "/play", search: { seats } });
            }}
          >
            Play offline
          </Button>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-sm tracking-[0.18em] text-brass">ROOM</h2>
          <p className="text-xs text-muted-foreground">Host creates a table. Others join with the code. Auto-starts when full.</p>
          <div className="flex flex-wrap items-center gap-2">
            {[2, 3, 4, 5, 6].map((n) => (
              <Button key={n} size="sm" variant={hostSeats === n ? "brass" : "outline" } onClick={() => setHostSeats(n)}>
                {n} seats
              </Button>
            ))}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pw">Password (optional)</Label>
            <Input
              id="pw"
              value={hostPassword}
              onChange={(e) => setHostPassword(e.target.value)}
              placeholder="Leave blank for an open room"
            />
          </div>
          <Button
            className="w-full"
            variant="secondary"
            disabled={!identity.id}
            onClick={() => {
              unlockAudio();
              const code = roomCode();
              sessionStorage.setItem(
                `swift-hand-host-${code}`,
                JSON.stringify({ password: hostPassword || null, seats: hostSeats, hostId: identity.id }),
              );
              void navigate({ to: "/r/$code", params: { code } });
            }}
          >
            Create room
          </Button>

          <div className="grid grid-cols-[1fr_auto] gap-2">
            <Input
              value={join}
              onChange={(e) => setJoin(e.target.value.toUpperCase())}
              placeholder="Room code"
              maxLength={6}
            />
            <Button
              variant="outline"
              onClick={() => {
                const code = join.trim().toUpperCase();
                if (code.length < 4) return;
                unlockAudio();
                if (password) sessionStorage.setItem(`swift-hand-join-${code}`, password);
                void navigate({ to: "/r/$code", params: { code } });
              }}
            >
              Join
            </Button>
          </div>
          <Input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Room password if it has one"
          />
        </section>
      </div>

      <div className="mt-6">
        <HowToPlay />
      </div>
    </main>
  );
}
