import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { GoldBar } from "@/components/gold-bar";
import { HowToPlay } from "@/components/how-to-play";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { loadIdentity, roomCode, saveIdentity, tableName } from "@/lib/identity";
import { fetchRooms, type ListedRoom } from "@/lib/lobby";
import { unlockAudio } from "@/audio/sfx.ts";

export function TitleScreen() {
  const navigate = useNavigate();
  const [identity, setIdentity] = useState({ id: "", name: "" });
  const [rooms, setRooms] = useState<ListedRoom[]>([]);
  const [lockJoin, setLockJoin] = useState<string | null>(null);

  useEffect(() => {
    setIdentity(loadIdentity());
  }, []);
  const [seats, setSeats] = useState(2);
  const [join, setJoin] = useState("");
  const [password, setPassword] = useState("");
  const [hostPassword, setHostPassword] = useState("");
  const [hostSeats, setHostSeats] = useState(2);

  useEffect(() => {
    let live = true;
    const pull = async () => {
      const list = await fetchRooms();
      if (live) setRooms(list);
    };
    void pull();
    const id = window.setInterval(() => void pull(), 2500);
    return () => {
      live = false;
      window.clearInterval(id);
    };
  }, []);

  function persistName(name: string) {
    const next = { ...identity, name: name.slice(0, 18) };
    setIdentity(next);
    saveIdentity(next);
  }

  function commitName() {
    const name = tableName(identity.name);
    const next = { ...identity, name };
    setIdentity(next);
    saveIdentity(next);
    return name;
  }

  function enterRoom(code: string, locked: boolean) {
    unlockAudio();
    if (locked) {
      setJoin(code);
      setLockJoin(code);
      return;
    }
    commitName();
    void navigate({ to: "/r/$code", params: { code } });
  }

  return (
    <main className="felt-table relative flex min-h-dvh flex-col items-center px-4 py-10 sm:py-16">
      <GoldBar />
      <p className="mt-6 max-w-md text-center text-sm leading-relaxed text-muted-foreground">
        One 52-card pack plus two Jokers. Dump or pick up. The Queen hangs. Debt stacks. The last card can still tax you.
      </p>

      <div className="mt-8 w-full max-w-md space-y-6 rounded-[28px] border border-border bg-surface/85 p-5 sm:p-6">
        <div className="space-y-1.5">
          <Label htmlFor="name">Your name at the table</Label>
          <Input
            id="name"
            value={identity.name}
            maxLength={18}
            placeholder="Player"
            onChange={(e) => persistName(e.target.value)}
          />
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-sm tracking-[0.18em] text-brass">OFFLINE</h2>
          <p className="text-xs text-muted-foreground">Same rules against the house. Good for Queen-hang and two-player bounce.</p>
          <div className="flex flex-wrap gap-2">
            {[2, 3, 4, 5, 6].map((n) => (
              <Button key={n} size="sm" variant={seats === n ? "brass" : "outline"} onClick={() => setSeats(n)}>
                {n}
              </Button>
            ))}
          </div>
          <Button
            className="w-full"
            variant="brass"
            disabled={!identity.id}
            onClick={() => {
              unlockAudio();
              commitName();
              void navigate({ to: "/play", search: { seats } });
            }}
          >
            Play offline
          </Button>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-sm tracking-[0.18em] text-brass">ROOM</h2>
          <p className="text-xs text-muted-foreground">Open tables show here. A padlock needs the password. Started hands leave the list.</p>

          {rooms.length > 0 && (
            <ul className="max-h-40 space-y-1 overflow-y-auto rounded-[var(--radius-sm)] border border-border bg-felt/60 p-1">
              {rooms.map((room) => (
                <li key={room.code}>
                  <button
                    type="button"
                    className="flex w-full items-center gap-2 rounded-[6px] px-2.5 py-2 text-left text-sm hover:bg-surface-2"
                    onClick={() => enterRoom(room.code, room.locked)}
                  >
                    {room.locked ? (
                      <Lock className="size-3.5 shrink-0 text-brass" aria-label="Password" />
                    ) : (
                      <span className="inline-block size-3.5 shrink-0" />
                    )}
                    <span className="font-medium tracking-wide text-ivory">{room.code}</span>
                    <span className="truncate text-xs text-muted-foreground">{room.host}</span>
                    <span className="ml-auto tabular-nums text-xs text-muted-foreground">
                      {room.seated}/{room.seats}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          {lockJoin && (
            <p className="text-xs text-brass">Room {lockJoin} is locked. Enter the password below, then Join.</p>
          )}
          <div className="flex flex-wrap items-center gap-2">
            {[2, 3, 4, 5, 6].map((n) => (
              <Button key={n} size="sm" variant={hostSeats === n ? "brass" : "outline" } onClick={() => setHostSeats(n)}>
                {n} seats
              </Button>
            ))}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pw">Password (optional)</Label>
            <Input
              id="pw"
              value={hostPassword}
              onChange={(e) => setHostPassword(e.target.value)}
              placeholder="Leave blank for an open room"
            />
          </div>
          <Button
            className="w-full"
            variant="secondary"
            disabled={!identity.id}
            onClick={() => {
              unlockAudio();
              commitName();
              const code = roomCode();
              sessionStorage.setItem(
                `swift-hand-host-${code}`,
                JSON.stringify({ password: hostPassword || null, seats: hostSeats, hostId: identity.id }),
              );
              void navigate({ to: "/r/$code", params: { code } });
            }}
          >
            Create room
          </Button>

          <div className="grid grid-cols-[1fr_auto] gap-2">
            <Input
              value={join}
              onChange={(e) => setJoin(e.target.value.toUpperCase())}
              placeholder="Room code"
              maxLength={6}
            />
            <Button
              variant="outline"
              onClick={() => {
                const code = join.trim().toUpperCase();
                if (code.length < 4) return;
                unlockAudio();
                commitName();
                if (password) sessionStorage.setItem(`swift-hand-join-${code}`, password);
                void navigate({ to: "/r/$code", params: { code } });
              }}
            >
              Join
            </Button>
          </div>
          <Input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Room password if it has one"
          />
        </section>
      </div>

      <div className="mt-6">
        <HowToPlay />
      </div>
    </main>
  );
}
