import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { GameTable, LobbyPanel } from "@/components/game-table";
import { GoldBar } from "@/components/gold-bar";
import { Button } from "@/components/ui/button";
import { createLobby, reduce } from "@/game/engine.ts";
import type { GameAction, GameState } from "@/game/types.ts";
import { loadIdentity, type Identity } from "@/lib/identity";
import { dropRoom, publishRoom } from "@/lib/lobby";
import { useRoomBus } from "@/lib/multiplayer";

type Wire =
  | { t: "hello"; name: string; password?: string }
  | { t: "reject"; reason: string; to?: string }
  | { t: "state"; state: GameState }
  | { t: "action"; action: GameAction };

function readHostConfig(code: string) {
  try {
    const raw = sessionStorage.getItem(`swift-hand-host-${code}`);
    if (!raw) return null;
    return JSON.parse(raw) as { password: string | null; seats: number; hostId: string };
  } catch {
    return null;
  }
}

export function RoomPlay({ code }: { code: string }) {
  const [identity, setIdentity] = useState<Identity | null>(null);
  useEffect(() => {
    setIdentity(loadIdentity());
  }, []);
  if (!identity) {
    return (
      <main className="felt-table flex min-h-dvh items-center justify-center">
        <GoldBar kicker={`Room ${code}`} subtitle="Taking your seat." />
      </main>
    );
  }
  return <RoomSession code={code} identity={identity} />;
}

function RoomSession({ code, identity }: { code: string; identity: Identity }) {
  const navigate = useNavigate();
  const hostConfig = readHostConfig(code);
  const isHost = hostConfig?.hostId === identity.id;
  const joinPassword = sessionStorage.getItem(`swift-hand-join-${code}`) ?? undefined;

  const [state, setState] = useState<GameState | null>(() => {
    if (!isHost || !hostConfig) return null;
    return createLobby({
      hostId: identity.id,
      hostName: identity.name === "Seat" ? "Host" : identity.name,
      roomCode: code,
      password: hostConfig.password,
      seatTarget: hostConfig.seats,
    });
  });
  const [error, setError] = useState<string | null>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  const bus = useRoomBus({
    room: `sh-${code}`,
    name: identity.name,
    selfId: identity.id,
  });
  const sendRef = useRef(bus.send);
  sendRef.current = bus.send;

  useEffect(() => {
    if (!isHost) return;
    let stopped = false;
    const beat = () => {
      const current = stateRef.current;
      if (!current || stopped) return;
      void publishRoom({
        code,
        host: current.players.find((p) => p.id === identity.id)?.name || identity.name,
        seats: current.seatTarget,
        seated: current.players.filter((p) => p.connected && !p.folded).length || current.players.length,
        locked: Boolean(current.password),
        started: current.started,
      });
    };
    beat();
    const id = window.setInterval(beat, 3500);
    return () => {
      stopped = true;
      window.clearInterval(id);
      if (!stateRef.current?.started) void dropRoom(code);
    };
  }, [isHost, code, identity.id, identity.name, state?.started, state?.players.length]);

  function applyHost(action: GameAction) {
    setState((prev) => {
      if (!prev) return prev;
      const next = reduce(prev, action);
      sendRef.current({ t: "state", state: next } satisfies Wire);
      return next;
    });
  }

  useEffect(() => {
    return bus.onMessage((from, data) => {
      const msg = data as Wire;
      if (!msg || typeof msg !== "object" || !("t" in msg)) return;

      if (isHost) {
        if (msg.t === "hello") {
          const current = stateRef.current;
          if (!current) return;
          if (current.password && msg.password !== current.password) {
            sendRef.current({ t: "reject", reason: "Wrong password.", to: from } satisfies Wire);
            return;
          }
          const existing = current.players.find((p) => p.id === from);
          if (existing) {
            const next = reduce(current, { type: "presence", playerId: from, connected: true, at: Date.now() });
            const named = reduce(next, { type: "rename", playerId: from, name: msg.name });
            setState(named);
            sendRef.current({ t: "state", state: named } satisfies Wire);
            return;
          }
          if (current.started) {
            sendRef.current({ t: "reject", reason: "Hand is already in play.", to: from } satisfies Wire);
            return;
          }
          const next = reduce(current, { type: "join", player: { id: from, name: msg.name, kind: "human" } });
          setState(next);
          sendRef.current({ t: "state", state: next } satisfies Wire);
          return;
        }
        if (msg.t === "action") {
          applyHost(msg.action);
        }
        return;
      }

      if (msg.t === "reject") {
        if (!msg.to || msg.to === identity.id) setError(msg.reason);
      }
      if (msg.t === "state") setState(msg.state);
    });
  }, [isHost, bus, identity.id]);

  useEffect(() => {
    if (isHost || state) return;
    if (!bus.joined) return;
    const hello = { t: "hello", name: identity.name, password: joinPassword } satisfies Wire;
    bus.send(hello);
    const id = window.setInterval(() => bus.send(hello), 1200);
    return () => window.clearInterval(id);
  }, [bus, bus.joined, isHost, identity.name, joinPassword, state]);

  useEffect(() => {
    if (!isHost) return;
    // Presence is inferred from hello retries; no WebRTC roster.
    let raf = 0;
    let last = 0;
    const tick = (now: number) => {
      if (now - last > 1000) {
        last = now;
        const current = stateRef.current;
        if (current?.started) {
          const t = Date.now();
          for (const player of current.players) {
            if (player.disconnectedAt && t - player.disconnectedAt >= 30_000 && !player.folded && !player.goneOut) {
              applyHost({ type: "fold", playerId: player.id });
            }
          }
        }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [isHost]);

  function onAction(action: GameAction) {
    if (isHost) applyHost(action);
    else bus.send({ t: "action", action } satisfies Wire);
  }

  if (error) {
    return (
      <main className="felt-table flex min-h-dvh flex-col items-center justify-center px-4">
        <GoldBar kicker="Room closed" subtitle={error} />
        <Button className="mt-6" variant="brass" onClick={() => void navigate({ to: "/" })}>
          Back
        </Button>
      </main>
    );
  }

  if (!state) {
    return (
      <main className="felt-table flex min-h-dvh flex-col items-center justify-center px-4">
        <GoldBar kicker={`Room ${code}`} subtitle={bus.joined ? "Sitting down…" : "Finding the table."} />
        <p className="mt-4 text-sm text-muted-foreground">
          {bus.joined ? "Waiting for the host to seat you." : "If this hangs, the host is not at the table."}
        </p>
        <Button className="mt-6" variant="ghost" onClick={() => void navigate({ to: "/" })}>
          Back
        </Button>
      </main>
    );
  }

  if (state.phase === "lobby" && !state.started) {
    return (
      <LobbyPanel
        state={state}
        selfId={identity.id}
        onAction={onAction}
        onStart={() => onAction({ type: "start" })}
      />
    );
  }

  return (
    <GameTable
      state={state}
      selfId={identity.id}
      onAction={onAction}
      onLeave={() => {
        onAction({ type: "leave", playerId: identity.id });
        void navigate({ to: "/" });
      }}
      online
    />
  );
}
