import { useEffect, useReducer, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { GameTable } from "@/components/game-table";
import { GoldBar } from "@/components/gold-bar";
import { chooseBotAction } from "@/game/bot.ts";
import { createOfflineTable, reduce } from "@/game/engine.ts";
import { currentPlayer } from "@/game/rules.ts";
import type { GameAction, GameState } from "@/game/types.ts";
import { loadIdentity } from "@/lib/identity";
import { sfxPlay } from "@/audio/sfx.ts";

function reducer(state: GameState, action: GameAction) {
  return reduce(state, action);
}

export function OfflinePlay({ seats }: { seats: number }) {
  const navigate = useNavigate();
  const [booted, setBooted] = useState<GameState | null>(null);

  useEffect(() => {
    const identity = loadIdentity();
    setBooted(
      createOfflineTable({
        humanId: identity.id,
        humanName: identity.name === "Seat" ? "You" : identity.name,
        seats,
      }),
    );
  }, [seats]);

  if (!booted) {
    return (
      <main className="felt-table flex min-h-dvh items-center justify-center">
        <GoldBar kicker="The house sits" subtitle="Dealing." />
      </main>
    );
  }

  return <OfflineTable initial={booted} selfId={booted.players[0]!.id} onLeave={() => void navigate({ to: "/" })} />;
}

function OfflineTable({
  initial,
  selfId,
  onLeave,
}: {
  initial: GameState;
  selfId: string;
  onLeave: () => void;
}) {
  const [state, dispatch] = useReducer(reducer, initial);
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    const actor = currentPlayer(state);
    if (!actor || actor.kind !== "bot") return;
    if (state.phase === "lobby" || state.phase === "hand-over") return;
    let raf = 0;
    let start = 0;
    const wait = 650 + Math.random() * 750;
    const tick = (now: number) => {
      if (!start) start = now;
      if (now - start >= wait) {
        const latest = stateRef.current;
        const current = currentPlayer(latest);
        if (!current || current.kind !== "bot") return;
        const action = chooseBotAction(latest, current.id);
        if (action) {
          if (action.type === "pickup") sfxPlay.pickup();
          else if (action.type === "dump") sfxPlay.place();
          dispatch(action);
        }
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [state.turnNumber, state.phase, state.currentSeat, state.pendingDumpIds]);

  return <GameTable state={state} selfId={selfId} onAction={dispatch} onLeave={onLeave} />;
}
