import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import type { ChatLine } from "@/game/types.ts";
import { cn } from "@/lib/utils";

export function TableChat({
  lines,
  onSend,
  placeholder = "Message the table",
  className,
  compact,
}: {
  lines: ChatLine[];
  onSend: (text: string) => void;
  placeholder?: string;
  className?: string;
  compact?: boolean;
}) {
  const [text, setText] = useState("");
  const scroller = useRef<HTMLOListElement>(null);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [lines.length]);

  return (
    <div className={cn("flex flex-col rounded-[16px] border border-border bg-surface/90", className)}>
      <p className="px-3 pt-2 font-display text-[10px] tracking-[0.22em] text-brass">CHAT</p>
      <ol
        ref={scroller}
        className={cn("space-y-1 overflow-y-auto px-3 py-2 text-xs leading-snug", compact ? "max-h-24" : "max-h-40 min-h-[6rem]")}
      >
        {lines.length === 0 ? (
          <li className="text-muted-foreground">No messages yet.</li>
        ) : (
          lines.map((line) => (
            <li key={line.id}>
              <span className="font-medium text-ivory">{line.name}</span>
              <span className="text-muted-foreground">: {line.text}</span>
            </li>
          ))
        )}
      </ol>
      <form
        className="flex gap-2 border-t border-border p-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!text.trim()) return;
          onSend(text);
          setText("");
        }}
      >
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={placeholder}
          maxLength={160}
          className="h-9 flex-1 rounded-[var(--radius-sm)] border border-border bg-felt px-3 text-sm"
        />
        <Button type="submit" size="sm" variant="outline">
          Send
        </Button>
      </form>
    </div>
  );
}
