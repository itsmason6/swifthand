let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sfx: GainNode | null = null;
let muted = false;

function ensure() {
  if (ctx) return;
  const AC = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return;
  ctx = new AC({ latencyHint: "interactive" });
  master = ctx.createGain();
  sfx = ctx.createGain();
  sfx.gain.value = 0.55;
  master.gain.value = muted ? 0 : 1;
  sfx.connect(master);
  master.connect(ctx.destination);
}

export function unlockAudio() {
  ensure();
  if (ctx && ctx.state === "suspended") void ctx.resume();
}

export function setMuted(value: boolean) {
  muted = value;
  if (master && ctx) master.gain.setTargetAtTime(value ? 0 : 1, ctx.currentTime, 0.02);
}

export function isMuted() {
  return muted;
}

function beep(freq: number, dur: number, type: OscillatorType, gain = 0.12, slide = 0) {
  ensure();
  if (!ctx || !sfx) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);
  if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), now + dur);
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(gain, now + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.connect(g);
  g.connect(sfx);
  osc.start(now);
  osc.stop(now + dur + 0.02);
  osc.onended = () => {
    osc.disconnect();
    g.disconnect();
  };
}

export const sfxPlay = {
  place: () => beep(180 + Math.random() * 40, 0.08, "triangle", 0.1, -40),
  pickup: () => beep(140, 0.12, "sine", 0.08, 60),
  debt: () => beep(90, 0.22, "sawtooth", 0.07, -30),
  reverse: () => beep(320, 0.16, "square", 0.05, 80),
  out: () => {
    beep(440, 0.18, "triangle", 0.1);
    setTimeout(() => beep(660, 0.22, "triangle", 0.08), 90);
  },
  error: () => beep(90, 0.1, "square", 0.05),
  swap: () => beep(240, 0.2, "sine", 0.08, 180),
};
