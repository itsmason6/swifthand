import { createFileRoute } from "@tanstack/react-router";
import { TitleScreen } from "@/components/title-screen";

export const Route = createFileRoute("/")({ component: TitleScreen });
