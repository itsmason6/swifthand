import { createFileRoute } from "@tanstack/react-router";
import { RoomPlay } from "@/components/room-play";

export const Route = createFileRoute("/r/$code")({
  component: RoomPage,
});

function RoomPage() {
  const { code } = Route.useParams();
  return <RoomPlay code={code.toUpperCase()} />;
}
