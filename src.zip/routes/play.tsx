import { createFileRoute } from "@tanstack/react-router";
import { OfflinePlay } from "@/components/offline-play";

type PlaySearch = { seats?: number };

export const Route = createFileRoute("/play")({
  validateSearch: (search: Record<string, unknown>): PlaySearch => ({
    seats: typeof search.seats === "number" ? search.seats : Number(search.seats) || 3,
  }),
  component: PlayPage,
});

function PlayPage() {
  const { seats } = Route.useSearch();
  const n = Math.min(6, Math.max(2, seats ?? 3));
  return <OfflinePlay seats={n} />;
}
