import {
  cardLabel,
  isAce,
  isBlackJack,
  isJoker,
  isKing,
  isQueen,
  isRedJack,
  isSeven,
  isTwo,
  shuffledDeck,
  suitName,
  suitOf,
} from "./cards.ts";
import { nextRng } from "./rng.ts";
import {
  currentPlayer,
  debtFromDump,
  isLegalDump,
  kingCount,
  nextSeatFrom,
  playerById,
  sevenCount,
  shouldBouncePrompt,
  shouldQueenPrompt,
  stillInCount,
  stillInPlayers,
  topCard,
} from "./rules.ts";
import type { Card, GameAction, GameState, PlayerState } from "./types.ts";

let logSeq = 0;

function clone<T>(value: T): T {
  return structuredClone(value);
}

function pushLog(state: GameState, text: string, at: number) {
  logSeq += 1;
  state.log.push({ id: `l${logSeq}`, text, at });
  if (state.log.length > 40) state.log.splice(0, state.log.length - 40);
  state.lastEvent = text;
}

function drawFromPile(state: GameState, n: number): Card[] {
  const drawn: Card[] = [];
  for (let i = 0; i < n; i++) {
    if (state.drawPile.length === 0) recycleDiscard(state);
    const card = state.drawPile.pop();
    if (!card) break;
    drawn.push(card);
  }
  return drawn;
}

function recycleDiscard(state: GameState) {
  if (state.discard.length <= 1) return;
  const top = state.discard.pop()!;
  const rest = state.discard.splice(0, state.discard.length);
  state.rngState = (state.rngState + 1) | 0;
  for (let i = rest.length - 1; i > 0; i--) {
    const n = nextRng(state.rngState);
    state.rngState = n.state;
    const j = Math.floor(n.value * (i + 1));
    const tmp = rest[i]!;
    rest[i] = rest[j]!;
    rest[j] = tmp;
  }
  state.drawPile = rest;
  state.discard = [top];
}

function cardsByIds(hand: Card[], ids: string[]): Card[] | null {
  const found: Card[] = [];
  const used = new Set<string>();
  for (const id of ids) {
    if (used.has(id)) return null;
    const card = hand.find((c) => c.id === id);
    if (!card) return null;
    found.push(card);
    used.add(id);
  }
  return found;
}

function removeCards(hand: Card[], ids: string[]): Card[] {
  const set = new Set(ids);
  return hand.filter((c) => !set.has(c.id));
}

function checkTableOver(state: GameState, at: number) {
  const living = stillInPlayers(state);
  if (living.length === 1) {
    const last = living[0]!;
    if (!last.goneOut) {
      last.goneOut = true;
      last.placement = state.placements.length + 1;
      state.placements.push(last.id);
      pushLog(state, `${last.name} takes the table.`, at);
    }
    state.phase = "hand-over";
    state.pendingDumpIds = null;
    state.pendingDebt = 0;
  } else if (living.length === 0) {
    state.phase = "hand-over";
  }
}

function markOut(state: GameState, player: PlayerState, at: number) {
  if (player.goneOut) return;
  player.goneOut = true;
  player.placement = state.placements.length + 1;
  state.placements.push(player.id);
  const place = player.placement === 1 ? "First seat." : `Place ${player.placement}.`;
  pushLog(state, `${player.name} is out. ${place}`, at);
}

function applyStarter(state: GameState, at: number) {
  const starter = topCard(state);
  if (!starter) return;
  state.currentSuit = suitOf(starter);
  state.direction = 1;
  state.currentSeat = 0;
  state.pendingDebt = 0;

  if (isTwo(starter)) {
    state.pendingDebt = 2;
    pushLog(state, `Starter 2 is live. ${currentPlayer(state)?.name ?? "First seat"} owes 2.`, at);
  } else if (isBlackJack(starter)) {
    state.pendingDebt = 5;
    pushLog(state, `Starter black Jack is live. Debt is 5.`, at);
  } else if (isRedJack(starter)) {
    pushLog(state, `Starter red Jack. Debt dies before it starts.`, at);
  } else if (isKing(starter)) {
    const skipped = currentPlayer(state);
    state.currentSeat = nextSeatFrom(state, state.currentSeat, 1);
    pushLog(state, `Starter King. ${skipped?.name ?? "First seat"} is skipped.`, at);
  } else if (isSeven(starter)) {
    state.direction = -1;
    state.currentSeat = nextSeatFrom(state, 0, 1);
    pushLog(state, `Starter 7. The table turns.`, at);
  } else if (isQueen(starter)) {
    pushLog(state, `Starter Queen. She is already hanging. Cover her or match her.`, at);
  } else if (isAce(starter)) {
    pushLog(state, `Starter Ace names ${suitName(state.currentSuit)}.`, at);
  } else if (isJoker(starter)) {
    pushLog(state, `Starter Joker. Suit is ${suitName(state.currentSuit)}. No swap.`, at);
  }
}

export function dealHand(state: GameState, at: number) {
  const seated = state.players
    .filter((p) => p.connected || p.kind === "bot")
    .sort((a, b) => a.seat - b.seat);
  if (seated.length < 2) return;

  const deck = shuffledDeck(state.rngState);
  state.rngState = deck.rngState;
  state.drawPile = deck.cards;
  state.discard = [];
  state.placements = [];
  state.pendingDumpIds = null;
  state.pendingDebt = 0;
  state.direction = 1;
  state.turnNumber = 1;
  state.started = true;
  state.phase = "turn";

  seated.forEach((p, i) => {
    p.seat = i;
    p.hand = [];
    p.folded = false;
    p.goneOut = false;
    p.placement = null;
    p.rematchReady = false;
  });
  state.players = seated;

  for (let round = 0; round < 7; round++) {
    for (const player of seated) {
      const card = state.drawPile.pop();
      if (card) player.hand.push(card);
    }
  }
  const starter = state.drawPile.pop();
  if (starter) state.discard.push(starter);
  applyStarter(state, at);
  const actor = currentPlayer(state);
  if (actor) pushLog(state, `${actor.name} to play.`, at);
}

export function createLobby(opts: {
  hostId: string;
  hostName: string;
  roomCode: string;
  password: string | null;
  seatTarget: number;
  seed?: number;
}): GameState {
  const seed = opts.seed ?? (Math.floor(Math.random() * 0xffffffff) || 1);
  return {
    version: 1,
    seed,
    rngState: seed,
    roomCode: opts.roomCode,
    password: opts.password,
    seatTarget: Math.min(6, Math.max(2, opts.seatTarget)),
    hostId: opts.hostId,
    players: [
      {
        id: opts.hostId,
        name: opts.hostName,
        seat: 0,
        hand: [],
        kind: "human",
        connected: true,
        folded: false,
        goneOut: false,
        placement: null,
        rematchReady: false,
        disconnectedAt: null,
      },
    ],
    drawPile: [],
    discard: [],
    currentSuit: "spades",
    direction: 1,
    currentSeat: 0,
    pendingDebt: 0,
    phase: "lobby",
    pendingDumpIds: null,
    log: [],
    chat: [],
    turnNumber: 0,
    placements: [],
    started: false,
    lastEvent: "Room is open.",
  };
}

export function createOfflineTable(opts: {
  humanId: string;
  humanName: string;
  seats: number;
  seed?: number;
}): GameState {
  const seats = Math.min(6, Math.max(2, opts.seats));
  const botNames = ["House", "Needle", "Gavel", "Mercy", "Quiet"];
  const state = createLobby({
    hostId: opts.humanId,
    hostName: opts.humanName,
    roomCode: "offline",
    password: null,
    seatTarget: seats,
    seed: opts.seed,
  });
  for (let i = 1; i < seats; i++) {
    state.players.push({
      id: `bot-${i}`,
      name: botNames[i - 1] ?? `Seat ${i + 1}`,
      seat: i,
      hand: [],
      kind: "bot",
      connected: true,
      folded: false,
      goneOut: false,
      placement: null,
      rematchReady: false,
      disconnectedAt: null,
    });
  }
  dealHand(state, Date.now());
  return state;
}

function advanceTurn(state: GameState, fromSeat: number, extraSkips: number, at: number) {
  const living = stillInCount(state);
  if (living <= 1) {
    checkTableOver(state, at);
    return;
  }
  const steps = 1 + extraSkips;
  const next = nextSeatFrom(state, fromSeat, steps);
  state.currentSeat = next;
  state.turnNumber += 1;
  state.phase = "turn";
  state.pendingDumpIds = null;
  const actor = currentPlayer(state);
  if (extraSkips > 0) {
    pushLog(state, `${extraSkips === 1 ? "A seat is" : extraSkips + " seats are"} skipped.`, at);
  }
  if (actor) {
    if (state.pendingDebt > 0) {
      pushLog(state, `${actor.name} faces a debt of ${state.pendingDebt}.`, at);
    } else {
      pushLog(state, `${actor.name} to play.`, at);
    }
  }
}

function applyDump(state: GameState, player: PlayerState, dump: Card[], at: number) {
  const fighting = state.pendingDebt > 0;
  const incoming = fighting ? state.pendingDebt : 0;
  player.hand = removeCards(player.hand, dump.map((c) => c.id));
  for (const card of dump) state.discard.push(card);

  pushLog(state, `${player.name} dumps ${dump.map(cardLabel).join(" · ")}.`, at);

  const last = dump[dump.length - 1]!;
  const emptyBeforeTax = player.hand.length === 0;

  if (isQueen(last)) {
    const tax = drawFromPile(state, 1);
    player.hand.push(...tax);
    pushLog(state, `The Queen hangs. ${player.name} picks up 1.`, at);
  }

  if (isAce(last) && player.hand.length > 0) {
    state.pendingDumpIds = dump.map((c) => c.id);
    state.phase = "pick-suit";
    state.pendingDebt = debtFromDump(dump, incoming);
    if (sevenCount(dump) % 2 === 1) state.direction = state.direction === 1 ? -1 : 1;
    pushLog(state, `${player.name} names the suit.`, at);
    return;
  }

  if (isAce(last)) {
    state.currentSuit = suitOf(last);
  } else {
    state.currentSuit = suitOf(last);
  }

  const wentOut = player.hand.length === 0 && !isQueen(last) && emptyBeforeTax;

  if (wentOut) {
    if (isJoker(last)) {
      pushLog(state, `Last card is a Joker. ${player.name} is out. The swap does nothing.`, at);
    }
    if (isSeven(last)) {
      pushLog(state, `Last card is a 7. ${player.name} is out.`, at);
    }
    markOut(state, player, at);
  } else if (isJoker(last) && player.hand.length > 0) {
    const nextId = nextSeatFrom(state, player.seat, 1);
    const other = state.players.find((p) => p.seat === nextId);
    if (other && other.id !== player.id) {
      const tmp = player.hand;
      player.hand = other.hand;
      other.hand = tmp;
      pushLog(state, `Joker swap. ${player.name} exchanges hands with ${other.name}.`, at);
    }
  }

  if (sevenCount(dump) % 2 === 1) {
    state.direction = state.direction === 1 ? -1 : 1;
    pushLog(state, "Direction flips.", at);
  }

  state.pendingDebt = debtFromDump(dump, incoming);

  if (wentOut) checkTableOver(state, at);
  if (state.phase === "hand-over") return;

  const skips = stillInCount(state) === 2 ? 0 : kingCount(dump);
  if (stillInCount(state) === 2 && (kingCount(dump) > 0 || sevenCount(dump) > 0) && !wentOut) {
    const bounced = nextSeatFrom(state, player.seat, 1 + kingCount(dump));
    state.currentSeat = bounced;
    state.turnNumber += 1;
    state.phase = "turn";
    state.pendingDumpIds = null;
    const actor = currentPlayer(state);
    if (actor?.id === player.id) {
      pushLog(state, `The ${kingCount(dump) ? "King" : "7"} bounces. ${player.name} must dump or pick up.`, at);
    } else if (actor) {
      if (state.pendingDebt > 0) pushLog(state, `${actor.name} faces a debt of ${state.pendingDebt}.`, at);
      else pushLog(state, `${actor.name} to play.`, at);
    }
    return;
  }

  advanceTurn(state, player.seat, skips, at);
}

function dumpAction(state: GameState, cardIds: string[], forceHang: boolean, at: number): GameState {
  const player = currentPlayer(state);
  if (!player) return state;
  if (state.phase !== "turn" && state.phase !== "queen-prompt" && state.phase !== "bounce-prompt") {
    return state;
  }
  const dump = cardsByIds(player.hand, cardIds);
  if (!dump) return state;
  const err = isLegalDump(dump, state);
  if (err) {
    pushLog(state, err, at);
    return state;
  }
  const remaining = removeCards(player.hand, cardIds);
  if (!forceHang && shouldQueenPrompt(dump, remaining, state)) {
    state.pendingDumpIds = cardIds;
    state.phase = "queen-prompt";
    pushLog(state, `${player.name} — cover the Queen or leave her hanging.`, at);
    return state;
  }
  if (!forceHang && shouldBouncePrompt(dump, remaining, state)) {
    state.pendingDumpIds = cardIds;
    state.phase = "bounce-prompt";
    const last = dump[dump.length - 1]!;
    pushLog(
      state,
      `${player.name} — hang that ${isKing(last) ? "King" : "7"}, or keep dumping.`,
      at,
    );
    return state;
  }
  applyDump(state, player, dump, at);
  return state;
}

export function reduce(state: GameState, action: GameAction, at = Date.now()): GameState {
  const next = clone(state);

  switch (action.type) {
    case "host-config": {
      if (next.started) break;
      next.seatTarget = Math.min(6, Math.max(2, action.seatTarget));
      next.password = action.password;
      break;
    }
    case "join": {
      if (playerById(next, action.player.id)) {
        const existing = playerById(next, action.player.id)!;
        existing.name = action.player.name;
        existing.connected = true;
        existing.disconnectedAt = null;
        if (existing.folded && !next.started) existing.folded = false;
        break;
      }
      if (next.started) break;
      if (next.players.length >= next.seatTarget) break;
      next.players.push({
        id: action.player.id,
        name: action.player.name,
        seat: next.players.length,
        hand: [],
        kind: action.player.kind,
        connected: true,
        folded: false,
        goneOut: false,
        placement: null,
        rematchReady: false,
        disconnectedAt: null,
      });
      pushLog(next, `${action.player.name} sits.`, at);
      if (next.players.length >= next.seatTarget) {
        dealHand(next, at);
      }
      break;
    }
    case "leave": {
      const player = playerById(next, action.playerId);
      if (!player) break;
      if (!next.started) {
        next.players = next.players.filter((p) => p.id !== action.playerId);
        next.players.forEach((p, i) => {
          p.seat = i;
        });
        pushLog(next, `${player.name} stands up.`, at);
        break;
      }
      if (!player.folded && !player.goneOut) {
        next.drawPile.unshift(...player.hand);
        player.hand = [];
        player.folded = true;
        pushLog(next, `${player.name} folds. Cards go under the deck.`, at);
        if (next.currentSeat === player.seat && next.phase !== "hand-over") {
          next.pendingDebt = 0;
          advanceTurn(next, player.seat, 0, at);
        }
        checkTableOver(next, at);
      }
      player.connected = false;
      break;
    }
    case "rename": {
      const player = playerById(next, action.playerId);
      if (player) player.name = action.name.slice(0, 18);
      break;
    }
    case "start": {
      if (next.started) break;
      if (next.players.length < 2) break;
      dealHand(next, at);
      break;
    }
    case "dump": {
      dumpAction(next, action.cardIds, Boolean(action.forceHang), at);
      break;
    }
    case "pickup": {
      if (next.phase !== "turn") break;
      const player = currentPlayer(next);
      if (!player) break;
      const n = next.pendingDebt > 0 ? next.pendingDebt : 1;
      const drawn = drawFromPile(next, n);
      player.hand.push(...drawn);
      const reason = next.pendingDebt > 0 ? `eats ${n}` : "picks up 1";
      pushLog(next, `${player.name} ${reason}.`, at);
      next.pendingDebt = 0;
      advanceTurn(next, player.seat, 0, at);
      break;
    }
    case "name-suit": {
      if (next.phase !== "pick-suit") break;
      const player = currentPlayer(next);
      if (!player) break;
      next.currentSuit = action.suit;
      pushLog(next, `${player.name} names ${suitName(action.suit)}. Turn ends.`, at);
      const dumpIds = next.pendingDumpIds ?? [];
      const dump = cardsByIds([...next.discard], dumpIds) ?? [];
      const skips = stillInCount(next) === 2 ? 0 : kingCount(dump);
      if (player.hand.length === 0) markOut(next, player, at);
      checkTableOver(next, at);
      if (stillInCount(next) <= 1) break;
      if (stillInCount(next) === 2 && (kingCount(dump) > 0 || sevenCount(dump) > 0) && !player.goneOut) {
        next.phase = "turn";
        next.pendingDumpIds = null;
        pushLog(next, `The bounce holds. ${player.name} must dump or pick up.`, at);
        break;
      }
      advanceTurn(next, player.seat, skips, at);
      break;
    }
    case "confirm-hang": {
      if (next.phase !== "queen-prompt" && next.phase !== "bounce-prompt") break;
      const ids = next.pendingDumpIds;
      if (!ids) break;
      next.phase = "turn";
      dumpAction(next, ids, true, at);
      break;
    }
    case "cancel-hang": {
      if (next.phase !== "queen-prompt" && next.phase !== "bounce-prompt") break;
      next.phase = "turn";
      next.pendingDumpIds = null;
      pushLog(next, "Dump held. Lay more, or pick another line.", at);
      break;
    }
    case "chat": {
      const player = playerById(next, action.playerId);
      const text = action.text.trim().slice(0, 160);
      if (!player || !text) break;
      next.chat.push({
        id: `c${at}-${next.chat.length}`,
        fromId: player.id,
        name: player.name,
        text,
        at,
      });
      if (next.chat.length > 80) next.chat.splice(0, next.chat.length - 80);
      break;
    }
    case "rematch": {
      if (next.phase !== "hand-over") break;
      const player = playerById(next, action.playerId);
      if (player) player.rematchReady = true;
      next.players.filter((p) => p.kind === "bot").forEach((p) => {
        p.rematchReady = true;
      });
      const humans = next.players.filter((p) => p.kind === "human" && p.connected);
      if (humans.length === 0) break;
      const onlineBots = next.players.filter((p) => p.kind === "bot");
      if (humans.length === 1 && onlineBots.length === 0) break;
      if (humans.every((p) => p.rematchReady) && humans.length + onlineBots.length >= 2) {
        dealHand(next, at);
      }
      break;
    }
    case "fold": {
      return reduce(next, { type: "leave", playerId: action.playerId }, at);
    }
    case "presence": {
      const player = playerById(next, action.playerId);
      if (!player) break;
      player.connected = action.connected;
      player.disconnectedAt = action.connected ? null : action.at;
      break;
    }
  }

  return next;
}

export function canHumanAct(state: GameState, playerId: string): boolean {
  if (state.phase === "hand-over" || state.phase === "lobby") return false;
  const actor = currentPlayer(state);
  return actor?.id === playerId;
}
