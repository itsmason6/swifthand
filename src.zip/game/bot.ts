import { isAce, isBlackJack, isJoker, isQueen, isRedJack, isTwo, suitOf } from "./cards.ts";
import { enumerateDumps, stillInCount, stillInPlayers } from "./rules.ts";
import type { Card, GameAction, GameState, Suit } from "./types.ts";

const SUIT_ORDER: Suit[] = ["spades", "hearts", "diamonds", "clubs"];

function majoritySuit(hand: Card[]): Suit {
  const counts: Record<Suit, number> = { spades: 0, hearts: 0, diamonds: 0, clubs: 0 };
  for (const card of hand) {
    if (!isJoker(card) && !isAce(card)) counts[suitOf(card)] += 1;
  }
  return SUIT_ORDER.reduce((best, suit) => (counts[suit] > counts[best] ? suit : best));
}

function scoreDump(dump: Card[], remaining: Card[], state: GameState): number {
  let score = dump.length * 120;
  const last = dump[dump.length - 1]!;
  const emptying = remaining.length === 0;

  if (emptying && isQueen(last)) score -= 800;
  else if (emptying) score += 5000;

  if (isQueen(last) && remaining.some((c) => suitOf(c) === suitOf(last) && !isJoker(c) && !isAce(c))) {
    score -= 600;
  }

  if (isJoker(dump[0]!) && remaining.length > 0) score -= 250;
  if (isJoker(last) && remaining.length > 0) {
    const next = stillInPlayers(state).find((p) => p.seat !== state.currentSeat);
    const myLeft = remaining.length;
    const their = next ? next.hand.length : 7;
    score += (their - myLeft) * 40;
  }

  if (state.pendingDebt > 0 && dump.some(isRedJack)) score += 300;
  if (state.pendingDebt > 0 && dump.some((c) => isTwo(c) || isBlackJack(c))) score += 80 + dump.length * 10;

  if (stillInCount(state) === 2 && emptying) score += 200;
  return score;
}

export function chooseBotAction(state: GameState, playerId: string): GameAction | null {
  const player = state.players.find((p) => p.id === playerId);
  if (!player) return null;

  if (state.phase === "pick-suit") {
    return { type: "name-suit", suit: majoritySuit(player.hand) };
  }
  if (state.phase === "queen-prompt" || state.phase === "bounce-prompt") {
    return { type: "cancel-hang" };
  }
  if (state.phase !== "turn") return null;

  const dumps = enumerateDumps(player.hand, state);
  if (dumps.length === 0) return { type: "pickup" };

  let best = dumps[0]!;
  let bestScore = -Infinity;
  for (const dump of dumps) {
    const remaining = player.hand.filter((c) => !dump.some((d) => d.id === c.id));
    const s = scoreDump(dump, remaining, state);
    if (s > bestScore) {
      bestScore = s;
      best = dump;
    }
  }
  return { type: "dump", cardIds: best.map((c) => c.id) };
}
