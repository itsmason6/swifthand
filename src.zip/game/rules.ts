import {
  isAce,
  isBlackJack,
  isConsecutive,
  isJack,
  isJoker,
  isKing,
  isQueen,
  isRedJack,
  isSeven,
  isTwo,
  sameRank,
  suitOf,
} from "./cards.ts";
import type { Card, FollowCtx, GameState, Suit } from "./types.ts";

export function topCard(state: GameState): Card | null {
  return state.discard.length ? state.discard[state.discard.length - 1]! : null;
}

/** Printed suit of the top card, except an Ace uses the named suit. */
export function playSuit(state: GameState): Suit {
  const top = topCard(state);
  if (!top) return state.currentSuit;
  if (isAce(top)) return state.currentSuit;
  return suitOf(top);
}

export function stillInPlayers(state: GameState) {
  return state.players.filter((p) => !p.folded && !p.goneOut);
}

export function stillInCount(state: GameState): number {
  return stillInPlayers(state).length;
}

export function playerById(state: GameState, id: string) {
  return state.players.find((p) => p.id === id) ?? null;
}

export function playerBySeat(state: GameState, seat: number) {
  return state.players.find((p) => p.seat === seat) ?? null;
}

export function currentPlayer(state: GameState) {
  return playerBySeat(state, state.currentSeat);
}

export function nextSeatFrom(state: GameState, fromSeat: number, steps = 1): number {
  const active = stillInPlayers(state).sort((a, b) => a.seat - b.seat);
  if (active.length === 0) return fromSeat;
  const order = active.map((p) => p.seat);
  const dir = state.direction;
  let idx = order.indexOf(fromSeat);
  if (idx < 0) {
    idx = order.findIndex((s) => (dir === 1 ? s > fromSeat : s < fromSeat));
    if (idx < 0) idx = dir === 1 ? 0 : order.length - 1;
    else if (dir === -1) {
      /* already the first seat "behind" */
    }
    steps -= 1;
    if (steps < 0) return order[idx]!;
  }
  const len = order.length;
  const moved = (idx + dir * steps) % len;
  return order[moved < 0 ? moved + len : moved]!;
}

export function canFightDebt(card: Card): boolean {
  return isTwo(card) || isBlackJack(card) || isRedJack(card);
}

export function canPlayFirst(card: Card, state: GameState): boolean {
  const top = topCard(state);
  if (!top) return true;
  if (state.pendingDebt > 0) return canFightDebt(card);
  if (isJoker(card) || isAce(card)) return true;
  if (sameRank(card, top) && !isJoker(top)) return true;
  if (suitOf(card) === playSuit(state)) return true;
  if ((isTwo(top) || isJack(top)) && (isTwo(card) || isJack(card))) return true;
  return false;
}

export function canFollow(prev: Card, next: Card, ctx: FollowCtx): boolean {
  if (isAce(prev)) return isAce(next);
  if (isJoker(next)) return true;
  if (isJoker(prev)) return isJoker(next);

  if (ctx.stillIn >= 3 && isKing(prev)) {
    return isKing(next);
  }

  if (isQueen(prev) && suitOf(next) === suitOf(prev) && !isJoker(next)) return true;
  if (ctx.stillIn === 2 && isSeven(prev) && suitOf(next) === suitOf(prev) && !isJoker(next)) return true;
  if ((isTwo(prev) || isJack(prev)) && (isTwo(next) || isJack(next))) return true;
  if (sameRank(prev, next) && !isJoker(prev)) return true;
  if (suitOf(prev) === suitOf(next) && isConsecutive(prev, next)) return true;

  if (ctx.stillIn === 2 && (isKing(prev) || isSeven(prev))) {
    if ((isTwo(next) || isBlackJack(next)) && suitOf(next) === suitOf(prev)) return true;
    if (isKing(next) || isSeven(next)) return true;
  }

  return false;
}

export function isLegalDump(cards: Card[], state: GameState): string | null {
  if (cards.length === 0) return "Dump at least one card.";
  const ctx: FollowCtx = { stillIn: stillInCount(state) };
  if (!canPlayFirst(cards[0]!, state)) {
    return state.pendingDebt > 0
      ? "Debt is live. Play a 2, a black Jack, or a red Jack — or pick up."
      : "The first card must match rank, the current suit, or be wild.";
  }
  for (let i = 1; i < cards.length; i++) {
    if (!canFollow(cards[i - 1]!, cards[i]!, ctx)) {
      return `${i + 1 === 2 ? "Second" : "Next"} card does not sit on the one before it.`;
    }
  }
  return null;
}

export function hasNonWildFollow(hand: Card[], last: Card, state: GameState): boolean {
  const ctx: FollowCtx = { stillIn: stillInCount(state) };
  return hand.some((c) => !isJoker(c) && !isAce(c) && canFollow(last, c, ctx));
}

export function shouldQueenPrompt(dump: Card[], remaining: Card[], state: GameState): boolean {
  const last = dump[dump.length - 1];
  if (!last || !isQueen(last)) return false;
  return hasNonWildFollow(remaining, last, state);
}

export function shouldBouncePrompt(dump: Card[], remaining: Card[], state: GameState): boolean {
  if (stillInCount(state) !== 2) return false;
  const last = dump[dump.length - 1];
  if (!last || !(isKing(last) || isSeven(last))) return false;
  return hasNonWildFollow(remaining, last, state);
}

export function debtFromDump(dump: Card[], incoming: number): number {
  const suffix: Card[] = [];
  for (let i = dump.length - 1; i >= 0; i--) {
    const card = dump[i]!;
    if (isTwo(card) || isBlackJack(card) || isRedJack(card)) suffix.unshift(card);
    else break;
  }
  if (suffix.length === 0) return 0;
  let debt = incoming;
  for (const card of suffix) {
    if (isTwo(card)) debt += 2;
    else if (isBlackJack(card)) debt += 5;
    else if (isRedJack(card)) debt = 0;
  }
  return debt;
}

export function kingCount(dump: Card[]): number {
  let n = 0;
  for (let i = dump.length - 1; i >= 0; i--) {
    if (!isKing(dump[i]!)) break;
    n += 1;
  }
  return n;
}

export function sevenCount(dump: Card[]): number {
  let n = 0;
  for (let i = dump.length - 1; i >= 0; i--) {
    if (!isSeven(dump[i]!)) break;
    n += 1;
  }
  return n;
}

export function legalStarters(hand: Card[], state: GameState): Card[] {
  return hand.filter((c) => canPlayFirst(c, state));
}

/** Depth-first search of legal dumps. Hands stay small; branching is tight. */
export function enumerateDumps(hand: Card[], state: GameState, cap = 400): Card[][] {
  const results: Card[][] = [];
  const ctx: FollowCtx = { stillIn: stillInCount(state) };

  function walk(used: Set<string>, seq: Card[]) {
    if (results.length >= cap) return;
    if (seq.length > 0) results.push(seq.slice());
    for (const card of hand) {
      if (used.has(card.id)) continue;
      const ok = seq.length === 0 ? canPlayFirst(card, state) : canFollow(seq[seq.length - 1]!, card, ctx);
      if (!ok) continue;
      used.add(card.id);
      seq.push(card);
      walk(used, seq);
      seq.pop();
      used.delete(card.id);
    }
  }

  walk(new Set(), []);
  return results;
}
