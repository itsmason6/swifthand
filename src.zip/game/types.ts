export const SUITS = ["spades", "hearts", "diamonds", "clubs"] as const;
export type Suit = (typeof SUITS)[number];

export type Rank = 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14;
export type CardRank = Rank | "joker";

export interface Card {
  id: string;
  suit: Suit;
  rank: CardRank;
  jokerColor?: "black" | "red";
}

export interface PlayerState {
  id: string;
  name: string;
  seat: number;
  hand: Card[];
  kind: "human" | "bot";
  connected: boolean;
  folded: boolean;
  goneOut: boolean;
  placement: number | null;
  rematchReady: boolean;
  disconnectedAt: number | null;
}

export type Phase =
  | "lobby"
  | "turn"
  | "pick-suit"
  | "queen-prompt"
  | "bounce-prompt"
  | "hand-over";

export interface TableLog {
  id: string;
  text: string;
  at: number;
  kind?: "dump" | "pickup" | "info";
  playerName?: string;
  playerId?: string;
  cards?: Card[];
  count?: number;
}

export interface ChatLine {
  id: string;
  fromId: string;
  name: string;
  text: string;
  at: number;
}

export interface GameState {
  version: 1;
  seed: number;
  rngState: number;
  roomCode: string;
  password: string | null;
  seatTarget: number;
  hostId: string;
  players: PlayerState[];
  drawPile: Card[];
  discard: Card[];
  currentSuit: Suit;
  direction: 1 | -1;
  currentSeat: number;
  pendingDebt: number;
  phase: Phase;
  pendingDumpIds: string[] | null;
  log: TableLog[];
  chat: ChatLine[];
  turnNumber: number;
  placements: string[];
  started: boolean;
  lastEvent: string;
}

export type GameAction =
  | { type: "host-config"; seatTarget: number; password: string | null }
  | { type: "join"; player: { id: string; name: string; kind: "human" | "bot" } }
  | { type: "leave"; playerId: string }
  | { type: "rename"; playerId: string; name: string }
  | { type: "start" }
  | { type: "dump"; cardIds: string[]; forceHang?: boolean }
  | { type: "pickup" }
  | { type: "name-suit"; suit: Suit }
  | { type: "confirm-hang" }
  | { type: "cancel-hang" }
  | { type: "chat"; playerId: string; text: string }
  | { type: "rematch"; playerId: string }
  | { type: "fold"; playerId: string }
  | { type: "presence"; playerId: string; connected: boolean; at: number };

export interface FollowCtx {
  stillIn: number;
}
