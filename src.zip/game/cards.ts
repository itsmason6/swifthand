import type { Card, CardRank, Rank, Suit } from "./types.ts";
import { SUITS } from "./types.ts";
import { shuffleInPlace } from "./rng.ts";

export const RANK_LABEL: Record<Rank, string> = {
  2: "2",
  3: "3",
  4: "4",
  5: "5",
  6: "6",
  7: "7",
  8: "8",
  9: "9",
  10: "10",
  11: "J",
  12: "Q",
  13: "K",
  14: "A",
};

const RANK_FILE: Record<Rank, string> = {
  2: "2",
  3: "3",
  4: "4",
  5: "5",
  6: "6",
  7: "7",
  8: "8",
  9: "9",
  10: "10",
  11: "jack",
  12: "queen",
  13: "king",
  14: "ace",
};

export const CARD_BACK_SRC = "/cards/back.jpg";

export function cardImageSrc(card: Card): string {
  if (isJoker(card)) {
    return card.jokerColor === "red" ? "/cards/red_joker.png" : "/cards/black_joker.png";
  }
  return `/cards/${RANK_FILE[card.rank as Rank]}_of_${card.suit}.png`;
}

export function suitOf(card: Card): Suit {
  return card.suit;
}

export function isJoker(card: Card): boolean {
  return card.rank === "joker";
}

export function isAce(card: Card): boolean {
  return card.rank === 14;
}

export function isTwo(card: Card): boolean {
  return card.rank === 2;
}

export function isSeven(card: Card): boolean {
  return card.rank === 7;
}

export function isJack(card: Card): boolean {
  return card.rank === 11;
}

export function isQueen(card: Card): boolean {
  return card.rank === 12;
}

export function isKing(card: Card): boolean {
  return card.rank === 13;
}

export function isBlackJack(card: Card): boolean {
  return isJack(card) && (card.suit === "spades" || card.suit === "clubs");
}

export function isRedJack(card: Card): boolean {
  return isJack(card) && (card.suit === "hearts" || card.suit === "diamonds");
}

export function isRedSuit(suit: Suit): boolean {
  return suit === "hearts" || suit === "diamonds";
}

export function rankLabel(rank: CardRank): string {
  if (rank === "joker") return "Joker";
  return RANK_LABEL[rank];
}

export function cardLabel(card: Card): string {
  if (isJoker(card)) return card.jokerColor === "red" ? "Red Joker" : "Black Joker";
  return `${RANK_LABEL[card.rank as Rank]}${suitGlyph(card.suit)}`;
}

/** Kill-feed label: King ♥, Jack ♣, 7♦ */
export function feedCardLabel(card: Card): string {
  if (isJoker(card)) return card.jokerColor === "red" ? "Red Joker" : "Black Joker";
  const glyph = suitGlyph(card.suit);
  switch (card.rank) {
    case 11:
      return `Jack ${glyph}`;
    case 12:
      return `Queen ${glyph}`;
    case 13:
      return `King ${glyph}`;
    case 14:
      return `Ace ${glyph}`;
    default:
      return `${RANK_LABEL[card.rank as Rank]}${glyph}`;
  }
}

export function suitGlyph(suit: Suit): string {
  switch (suit) {
    case "spades":
      return "♠";
    case "hearts":
      return "♥";
    case "diamonds":
      return "♦";
    case "clubs":
      return "♣";
  }
}

export function suitName(suit: Suit): string {
  return suit[0]!.toUpperCase() + suit.slice(1);
}

export function runIndex(card: Card): number | null {
  if (card.rank === "joker" || card.rank === 14) return null;
  return card.rank - 2;
}

export function isConsecutive(a: Card, b: Card): boolean {
  const ia = runIndex(a);
  const ib = runIndex(b);
  if (ia === null || ib === null) return false;
  return Math.abs(ia - ib) === 1;
}

export function makeDeck(): Card[] {
  const cards: Card[] = [];
  let n = 0;
  for (const suit of SUITS) {
    for (let rank = 2; rank <= 14; rank++) {
      cards.push({ id: `c${n++}`, suit, rank: rank as Rank });
    }
  }
  cards.push({ id: `c${n++}`, suit: "spades", rank: "joker", jokerColor: "black" });
  cards.push({ id: `c${n++}`, suit: "hearts", rank: "joker", jokerColor: "red" });
  return cards;
}

export function shuffledDeck(rngState: number): { cards: Card[]; rngState: number } {
  const cards = makeDeck();
  const next = shuffleInPlace(cards, rngState);
  return { cards, rngState: next };
}

export function sameRank(a: Card, b: Card): boolean {
  return a.rank === b.rank;
}
