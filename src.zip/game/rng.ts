/** Mulberry32 — small, seedable, good enough for a card table. */
export function nextRng(state: number): { state: number; value: number } {
  let a = (state + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  const value = ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  return { state: a, value };
}

export function shuffleInPlace<T>(items: T[], rngState: number): number {
  let state = rngState;
  for (let i = items.length - 1; i > 0; i--) {
    const n = nextRng(state);
    state = n.state;
    const j = Math.floor(n.value * (i + 1));
    const tmp = items[i]!;
    items[i] = items[j]!;
    items[j] = tmp;
  }
  return state;
}
