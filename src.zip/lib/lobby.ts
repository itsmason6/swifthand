export type ListedRoom = {
  code: string;
  host: string;
  seats: number;
  seated: number;
  locked: boolean;
};

async function parse(res: Response) {
  try {
    return (await res.json()) as { rooms?: ListedRoom[]; ok?: boolean };
  } catch {
    return {};
  }
}

export async function fetchRooms(): Promise<ListedRoom[]> {
  try {
    const res = await fetch("/api/rtc?lobby=1", { cache: "no-store" });
    if (!res.ok) return [];
    const body = await parse(res);
    return Array.isArray(body.rooms) ? body.rooms : [];
  } catch {
    return [];
  }
}

export async function publishRoom(info: {
  code: string;
  host: string;
  seats: number;
  seated: number;
  locked: boolean;
  started: boolean;
}) {
  try {
    await fetch("/api/rtc", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ op: "lobby", ...info }),
    });
  } catch {
    /* listing is best-effort */
  }
}

export async function dropRoom(code: string) {
  try {
    await fetch("/api/rtc", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ op: "lobby-leave", code }),
    });
  } catch {
    /* ignore */
  }
}
