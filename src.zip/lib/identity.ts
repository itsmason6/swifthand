const KEY = "swift-hand-identity";

export const DEFAULT_NAME = "Player";

export interface Identity {
  id: string;
  name: string;
}

function randomId() {
  return `p-${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 6)}`;
}

/** Empty / old "Seat" names become Player when you sit down. */
export function tableName(name: string | undefined): string {
  const trimmed = (name ?? "").trim();
  if (!trimmed || trimmed === "Seat") return DEFAULT_NAME;
  return trimmed.slice(0, 18);
}

export function loadIdentity(): Identity {
  if (typeof window === "undefined") return { id: "ssr", name: "" };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Identity;
      if (parsed.id) {
        const name = parsed.name === "Seat" ? "" : (parsed.name ?? "");
        return { id: parsed.id, name };
      }
    }
  } catch {
    /* ignore */
  }
  const fresh = { id: randomId(), name: "" };
  localStorage.setItem(KEY, JSON.stringify(fresh));
  return fresh;
}

export function saveIdentity(next: Identity) {
  localStorage.setItem(KEY, JSON.stringify(next));
}

export function roomCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 5; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  return out;
}
