import { useCallback, useEffect, useRef, useState } from "react";

type BusRow = { id: number; from: string; payload: unknown };

export interface RoomBusHandle {
  joined: boolean;
  send: (data: unknown) => void;
  onMessage: (fn: (from: string, data: unknown) => void) => () => void;
}

export function useRoomBus(opts: { room: string; selfId: string; name: string }): RoomBusHandle {
  const [joined, setJoined] = useState(false);
  const cursor = useRef(0);
  const closed = useRef(false);
  const listeners = useRef(new Set<(from: string, data: unknown) => void>());

  const send = useCallback(
    (data: unknown) => {
      void fetch("/api/rtc", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ op: "bus", room: opts.room, from: opts.selfId, payload: data }),
      }).catch(() => {});
    },
    [opts.room, opts.selfId],
  );

  useEffect(() => {
    closed.current = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const poll = async () => {
      if (closed.current) return;
      try {
        const params = new URLSearchParams({
          room: opts.room,
          peer: opts.selfId,
          name: opts.name,
          since: "0",
          busSince: String(cursor.current),
        });
        const res = await fetch(`/api/rtc?${params}`, { cache: "no-store" });
        if (!res.ok) throw new Error(String(res.status));
        const body = (await res.json()) as { bus?: BusRow[] };
        if (closed.current) return;
        setJoined(true);
        for (const row of body.bus ?? []) {
          cursor.current = Math.max(cursor.current, row.id);
          const payload =
            typeof row.payload === "string" ? (JSON.parse(row.payload) as unknown) : row.payload;
          for (const fn of listeners.current) fn(row.from, payload);
        }
      } catch {
        /* retry */
      }
      if (!closed.current) timer = setTimeout(() => void poll(), 400);
    };

    void poll();
    return () => {
      closed.current = true;
      if (timer) clearTimeout(timer);
    };
  }, [opts.room, opts.selfId, opts.name]);

  const onMessage = useCallback((fn: (from: string, data: unknown) => void) => {
    listeners.current.add(fn);
    return () => {
      listeners.current.delete(fn);
    };
  }, []);

  return { joined, send, onMessage };
}
